#!/bin/bash
set -euo pipefail

GW_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GW_CONF=/etc/wisp/config.env
GW_STATE=/var/lib/gateway-wisp
GW_BACKUP=/var/backups/wisp
GW_MARKERS="$GW_STATE/components"
GW_APT_UPDATED=${GW_APT_UPDATED:-0}
mkdir -p "$GW_STATE" "$GW_MARKERS" "$GW_BACKUP"

say(){ printf '%s\n' "$*"; }
need_root(){ [ "$(id -u)" -eq 0 ] || { say 'ERROR: esta operación necesita root. Ejecuta con sudo.'; exit 1; }; }
need_debian(){
  [ -r /etc/os-release ] || { say 'ERROR: no pude identificar la distribución.'; exit 1; }
  # shellcheck disable=SC1091
  . /etc/os-release
  case "${ID:-}" in
    debian|ubuntu) ;;
    *) say "ERROR: Gateway WISP modular 1.5.0 solo modifica automáticamente Debian/Ubuntu. Detectado: ${ID:-desconocido}."; exit 1 ;;
  esac
}
apt_update_once(){
  if [ "${GW_APT_UPDATED:-0}" != 1 ]; then
    DEBIAN_FRONTEND=noninteractive apt-get update -y
    GW_APT_UPDATED=1
  fi
}
apt_install(){ apt_update_once; DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"; }
mark(){ mkdir -p "$GW_MARKERS"; printf '%s\n' "$(date -u +%FT%TZ)" > "$GW_MARKERS/$1"; }
unmark(){ rm -f "$GW_MARKERS/$1"; }
marked(){ [ -f "$GW_MARKERS/$1" ]; }
backup_file(){ local f="$1" tag="$2"; [ -e "$f" ] || return 0; mkdir -p "$GW_STATE/backups"; cp -a "$f" "$GW_STATE/backups/${tag}.$(date +%Y%m%d_%H%M%S)"; }

valid_port(){ [[ "${1:-}" =~ ^[0-9]+$ ]] && [ "$1" -ge 1 ] && [ "$1" -le 65535 ]; }
valid_iface(){ [[ "${1:-}" =~ ^[A-Za-z0-9_.:-]{1,32}$ ]]; }
valid_ipv4_cidr(){ [[ "${1:-}" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/([0-9]|[12][0-9]|3[0-2])$ ]]; }
valid_ipv4(){ [[ "${1:-}" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; }
valid_bandwidth(){ [ -z "${1:-}" ] || [[ "$1" =~ ^[0-9]+([KMG])?bit$ ]]; }

ensure_conf(){ mkdir -p /etc/wisp; touch "$GW_CONF"; chmod 600 "$GW_CONF"; }
get_conf(){ local k="$1"; ensure_conf; ( set +u; source "$GW_CONF" 2>/dev/null || true; eval "printf '%s' \"\${$k:-}\"" ); }
set_conf(){
  local k="$1" v="$2" tmp
  ensure_conf; tmp=$(mktemp)
  grep -v -E "^${k}=" "$GW_CONF" > "$tmp" || true
  v=${v//\\/\\\\}; v=${v//\"/\\\"}
  printf '%s="%s"\n' "$k" "$v" >> "$tmp"
  install -m 600 "$tmp" "$GW_CONF"; rm -f "$tmp"
}
ask(){ local prompt="$1" def="${2:-}" out; if [ -n "$def" ]; then read -r -p "$prompt [$def]: " out; printf '%s' "${out:-$def}"; else read -r -p "$prompt: " out; printf '%s' "$out"; fi; }
ask_yes_no(){ local prompt="$1" def="${2:-N}" out; read -r -p "$prompt [$def]: " out; out=${out:-$def}; [[ "$out" =~ ^[sSyY] ]]; }

random_wg_port(){ command -v shuf >/dev/null 2>&1 && shuf -i 20000-59999 -n1 || printf '51888'; }
random_subnet(){
  if command -v shuf >/dev/null 2>&1; then printf '10.%s.%s.0/24' "$(shuf -i 2-254 -n1)" "$(shuf -i 0-254 -n1)"; else printf '10.66.66.0/24'; fi
}
ensure_network_conf(){
  local v def sub
  v=$(get_conf WG_PORT); if ! valid_port "${v:-}"; then def=$(random_wg_port); while :; do v=$(ask 'Puerto WireGuard UDP' "$def"); valid_port "$v" && break; say 'Puerto inválido.'; done; set_conf WG_PORT "$v"; fi
  v=$(get_conf WG_SUBNET); if ! valid_ipv4_cidr "${v:-}"; then def=$(random_subnet); while :; do v=$(ask 'Subred WireGuard' "$def"); valid_ipv4_cidr "$v" && break; say 'Subred inválida.'; done; set_conf WG_SUBNET "$v"; fi
  v=$(get_conf WG_SERVER_IP); if ! valid_ipv4 "${v:-}"; then sub=$(get_conf WG_SUBNET); def=$(printf '%s' "$sub" | cut -d/ -f1 | awk -F. '{print $1"."$2"."$3".1"}'); while :; do v=$(ask 'IP del servidor dentro de WireGuard' "$def"); valid_ipv4 "$v" && break; say 'IP inválida.'; done; set_conf WG_SERVER_IP "$v"; fi
  v=$(get_conf WG_IFACE); if ! valid_iface "${v:-}"; then while :; do v=$(ask 'Interfaz WireGuard' 'wg0'); valid_iface "$v" && break; say 'Interfaz inválida.'; done; set_conf WG_IFACE "$v"; fi
  v=$(get_conf PUB_IFACE); if ! valid_iface "${v:-}"; then v=$(ip -o -4 route show to default | awk '{print $5; exit}'); [ -n "$v" ] || { say 'ERROR: no pude detectar interfaz pública.'; exit 1; }; set_conf PUB_IFACE "$v"; fi
}

current_ssh_port(){ local d; d=$(command -v sshd 2>/dev/null || true); [ -n "$d" ] || d=/usr/sbin/sshd; "$d" -T 2>/dev/null | awk '$1=="port"{print $2; exit}' | grep -E '^[0-9]+$' || printf '22'; }
component_status(){
  case "$1" in
    system) [ -f /etc/sysctl.d/99-wisp-gateway.conf ] && echo installed || echo absent ;;
    wireguard) command -v wg >/dev/null 2>&1 && echo installed || echo absent ;;
    firewall) command -v nft >/dev/null 2>&1 && systemctl is-enabled nftables >/dev/null 2>&1 && echo installed || echo absent ;;
    qos) [ -f /etc/systemd/system/qos-cake-wg0.service ] && echo installed || echo absent ;;
    dns) (systemctl list-unit-files 2>/dev/null | grep -Eq '^(AdGuardHome|dns|ctrld)\.service' || command -v ctrld >/dev/null 2>&1) && echo installed || echo absent ;;
    wgdashboard) [ -x /root/WGDashboard/src/wgd.sh ] && echo installed || echo absent ;;
    crowdsec) command -v cscli >/dev/null 2>&1 && echo installed || echo absent ;;
    netdata) (command -v netdata >/dev/null 2>&1 || systemctl list-unit-files 2>/dev/null | grep -q '^netdata.service') && echo installed || echo absent ;;
    panel) [ -f /etc/systemd/system/panel-wisp.service ] && echo installed || echo absent ;;
    maintenance) [ -f /etc/systemd/system/backup-wisp.timer ] && echo installed || echo absent ;;
    *) echo unknown ;;
  esac
}
