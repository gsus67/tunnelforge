#!/bin/bash
# ==============================================================================
# Script de aprovisionamiento VPS - Gateway WISP  [VERSION 12]
# WireGuard + nftables + CrowdSec + ControlD via ctrld (DoH nativo)
# ==============================================================================
# HISTORIAL DE VERSIONES
# ------------------------------------------------------------------------------
# v5: - Cliente NATIVO de ControlD (ctrld) para DoH, reemplaza dnsmasq +
#       cloudflared. DoH3/DoQ nativo, cache propio, clientes visibles en panel.
#     - Base: WireGuard + WGDashboard + nftables (NAT, proteccion de
#       reputacion, DNS forzado) + CrowdSec + Netdata
#
# v6: - CrowdSec arranca en orden correcto: agente primero, bouncer despues
#       (auto-registro contra la LAPI) y con enable --now (v5 no lo arrancaba)
#     - Drop-in systemd PartOf: restart de nftables reinicia el bouncer solo
#       ("flush ruleset" borraba las tablas crowdsec y quedabas sin baneos)
#     - Metricas Prometheus: agente (127.0.0.1:6060) y bouncer (:60601),
#       scrapeadas automaticamente por Netdata
#     - Verificacion post-install del bouncer (estado, tablas nft, cscli)
#
# v7: RENDIMIENTO:
#     - MSS clamping en forward (evita webs colgadas por MTU 1420 del tunel)
#     - UDP GRO forwarding en la interfaz publica (+throughput WireGuard)
#     - Sysctl tuning: buffers UDP 16MB, fq_codel, conntrack_max=262144
#     SEGURIDAD:
#     - Anti-spoofing: solo se forwardea trafico del tunel con saddr del rango
#     - Aislamiento entre clientes (peer no ve a peer)
#     - ct state invalid drop tambien en forward
#     - unattended-upgrades (parches de seguridad automaticos)
#     - NOTA: SSH queda con password por decision del operador
#
# v8: QoS con prioridades (marcado DSCP + CAKE diffserv8 en wg0)
#     - Orden: 1) ping (CS7)  2) juegos (CS6)  3) social (CS4)
#              4) streaming (CS2)  5) resto (CS0 / best effort)
#     - nftables marca el DSCP segun tipo de trafico (sets editables)
#     - CAKE en wg0: 8 niveles de prioridad + reparto justo por cliente
#       (dual-dsthost: un cliente con torrents no ahoga a los demas)
#     - El DSCP viaja DENTRO del tunel cifrado: el MikroTik lo lee al
#       descifrar y puede aplicar colas en el cuello REAL (los radios)
#
# v9: Auto-actualizacion de los sets de IPs de QoS
#     - /usr/local/sbin/actualizar-qos-ips.sh consulta RADB por ASN
#       (Meta, X, Netflix) y refresca redes_social / redes_streaming
#     - Timer systemd semanal + re-aplicacion tras cada restart de nftables
#     - Proteccion: si RADB devuelve pocos prefijos, el set actual queda intacto
#     - auto-merge en los sets (RADB devuelve prefijos solapados)
#
# v10: Escalado a ~1000 clientes / ~1 Gbps + operacion
#     - CAKE_BANDWIDTH como variable al inicio (limite del shaper; ~90% del
#       throughput real medido = la priorizacion funciona DE VERDAD en el VPS)
#     - conntrack_max a 1M + hashsize 262144 (1000 clientes NATeados)
#     - irqbalance (reparte interrupciones de red entre cores)
#     - Cache DNS de ctrld ampliado (65536 registros)
#     - vnstat: contabilidad de trafico mensual en la interfaz publica
#     - Backup diario de configs (WireGuard, nftables, ctrld, CrowdSec,
#       peers de WGDashboard) con rotacion de 14 dias en /var/backups/wisp
#
# v11: Panel de control local integrado (localhost:8888)
#     - Dashboard estilo NOC con enlaces a todo: WGDashboard, Netdata,
#       CrowdSec Console, ControlD y endpoints Prometheus (6060/60601)
#     - LEDs de estado en vivo (chequean cada servicio cada 30s)
#     - Comando del tunel SSH con boton Copiar + chuleta de comandos
#     - Servido solo en 127.0.0.1 (python3 http.server endurecido via systemd)
#
# v13: DNS a elegir en la instalacion
#     - ControlD (ctrld, DoH3 en la nube) o AdGuard Home (autohospedado)
#     - AdGuard: panel solo en localhost (via tunel SSH), listas de bloqueo
#       base, cache 64MB y DNSSEC; upstreams cifrados (Cloudflare/Quad9 DoH)
#     - El panel del gateway muestra el enlace del DNS que corresponda
#
# v14: Tercera opcion de DNS — Technitium (servidor DNS completo)
#     - Para quien necesita zonas propias / DNS interno ademas de filtrar
#     - Con advertencia y doble confirmacion: corre sobre .NET y consume
#       ~100-150 MB de RAM extra frente a AdGuard
#
# v12: Instalador interactivo
#     - Las variables se piden por pantalla al correr el script
#     - Sugerencias GENERADAS AL AZAR para puerto WG y subred (cada VPS
#       queda distinto; Enter las acepta o escribes la tuya)
#     - Se guardan en /etc/wisp/config.env (chmod 600, fuera del repo)
#     - Si la config ya existe, pregunta si reutilizarla
#     - Sin terminal interactiva: exige config.env previa (para automatizacion)
#     - Al terminar, auto-sincroniza con las plantillas del repo (actualizar.sh)
# ==============================================================================
# Uso: sudo bash setup-vps-wisp.sh
# ==============================================================================

set -e

# ------------------------------------------------------------------------------
# VARIABLES — se piden interactivamente y se guardan en /etc/wisp/config.env
# ------------------------------------------------------------------------------
CONF=/etc/wisp/config.env

if [ -f "$CONF" ]; then
    echo ""
    echo "Ya existe configuracion en $CONF:"
    grep -v '^#' "$CONF" | grep . | sed 's/^/   /'
    echo ""
    read -rp "¿Usarla tal cual? [S/n]: " R
    if [[ "$R" =~ ^[nN] ]]; then
        rm -f "$CONF"
    else
        source "$CONF"
    fi
fi

if [ ! -f "$CONF" ]; then
    if [ ! -t 0 ]; then
        echo "ERROR: no hay terminal interactiva y no existe $CONF."
        echo "Opcion A: corre este script desde una terminal (SSH normal)."
        echo "Opcion B: crea la config a mano y reintenta:"
        echo "   mkdir -p /etc/wisp && cp config.env.ejemplo $CONF && nano $CONF"
        exit 1
    fi

    echo ""
    echo "──────────────────────────────────────────────────"
    echo " Configuracion del gateway"
    echo " Las sugerencias entre [ ] se GENERAN AL AZAR para"
    echo " este VPS (puerto y subred unicos = menos escaneos"
    echo " y sin choques de rango). Enter acepta la sugerencia"
    echo " o escribe el valor que prefieras."
    echo "──────────────────────────────────────────────────"

    SUG_PORT=$(shuf -i 20000-59999 -n1)
    [ "$SUG_PORT" = "51820" ] && SUG_PORT=52815   # nunca sugerir el default de WG
    while :; do
        read -rp "Puerto WireGuard UDP           [${SUG_PORT}]: " X
        WG_PORT="${X:-$SUG_PORT}"
        if [ "$WG_PORT" = "51820" ]; then
            echo "   → 51820 es el puerto DEFAULT de WireGuard: es el primero que escanean."
            echo "     Funciona, pero se recomienda otro. ¿Seguro?"
            read -rp "     Usar 51820 igual? [s/N]: " R
            [[ "$R" =~ ^[sS] ]] && break || continue
        fi
        [[ "$WG_PORT" =~ ^[0-9]+$ ]] && [ "$WG_PORT" -ge 1024 ] && [ "$WG_PORT" -le 65535 ] && break
        echo "   → Debe ser un numero entre 1024 y 65535."
    done

    SUG_O2=$(shuf -i 2-254 -n1)
    SUG_O3=$(shuf -i 0-254 -n1)
    SUG_SUBNET="10.${SUG_O2}.${SUG_O3}.0/24"
    while :; do
        read -rp "Subred del tunel      [${SUG_SUBNET}]: " X
        WG_SUBNET="${X:-$SUG_SUBNET}"
        [[ "$WG_SUBNET" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}$ ]] && break
        echo "   → Formato invalido. Ejemplo: 10.66.23.0/24"
    done
    DEF_IP=$(echo "$WG_SUBNET" | cut -d/ -f1 | awk -F. '{print $1"."$2"."$3".1"}')
    read -rp "IP del servidor en el tunel    [${DEF_IP}]: " X
    WG_SERVER_IP="${X:-$DEF_IP}"
    read -rp "Nombre de la interfaz                [wg0]: " X
    WG_IFACE="${X:-wg0}"

    echo ""
    echo "  DNS filtrado para tus clientes:"
    echo "    [1] ControlD  — filtrado en la nube (ctrld con DoH3). Reglas y"
    echo "        estadisticas en el panel web de ControlD. Cero mantenimiento."
    echo "    [2] AdGuard Home — servidor propio EN ESTE VPS. Tus reglas, tus"
    echo "        logs, nada sale a terceros. Panel web propio via tunel SSH."
    echo "        Ligero (Go): ~20-50 MB de RAM. RECOMENDADO para filtrar."
    echo "    [3] Technitium — servidor DNS COMPLETO autohospedado: ademas de"
    echo "        filtrar, resuelve zonas propias (nombres internos tuyos),"
    echo "        split-horizon, DoH/DoT nativo."
    echo "        OJO: corre sobre .NET — ~80-150 MB de RAM y ~150-250 MB de"
    echo "        disco (3-4x AdGuard). Elige esto SOLO si necesitas DNS"
    echo "        interno o zonas propias; para solo filtrar, sobra AdGuard."
    while :; do
        read -rp "  Cual usas? [1/2/3]                      [1]: " X
        case "${X:-1}" in
            1) DNS_PROVIDER="controld";   break ;;
            2) DNS_PROVIDER="adguard";    break ;;
            3) DNS_PROVIDER="technitium"
               echo ""
               echo "   ADVERTENCIA: Technitium consume bastante mas que AdGuard."
               echo "   En un gateway que ya corre CrowdSec, Netdata y WGDashboard,"
               echo "   son ~100-150 MB de RAM extra permanentes por el runtime .NET."
               read -rp "   ¿Seguro que quieres Technitium? [s/N]: " R
               if [[ "$R" =~ ^[sS] ]]; then break; fi
               echo "   → Elige otra opcion."
               ;;
            *) echo "   → Escribe 1, 2 o 3." ;;
        esac
    done

    CONTROLD_RESOLVER_ID=""
    CONTROLD_BOOTSTRAP_IP="76.76.2.22"
    ADGUARD_PORT="3000"
    TECHNITIUM_PORT="5380"
    if [ "$DNS_PROVIDER" = "technitium" ]; then
        read -rp "Puerto del panel de Technitium     [5380]: " X
        TECHNITIUM_PORT="${X:-5380}"
        echo "   → El panel escuchara SOLO en localhost:${TECHNITIUM_PORT} (via tunel SSH)."
    elif [ "$DNS_PROVIDER" = "controld" ]; then
        while :; do
            read -rp "Resolver ID de ControlD       (obligatorio): " CONTROLD_RESOLVER_ID
            [ -n "$CONTROLD_RESOLVER_ID" ] && break
            echo "   → No puede quedar vacio. Esta en 'Show Resolvers' de tu endpoint de ControlD."
        done
        read -rp "IP bootstrap de ControlD      [76.76.2.22]: " X
        CONTROLD_BOOTSTRAP_IP="${X:-76.76.2.22}"
    else
        read -rp "Puerto del panel de AdGuard        [3000]: " X
        ADGUARD_PORT="${X:-3000}"
        echo "   → El panel de AdGuard escuchara SOLO en localhost:${ADGUARD_PORT}"
        echo "     (se accede por tunel SSH, como los demas paneles)."
    fi

    echo ""
    echo "Limite del shaper CAKE: ~90% del throughput real del VPS (iperf3)."
    read -rp "Limite CAKE  [900mbit]  ('no' = sin limite): " X
    case "$X" in
        "")     CAKE_BANDWIDTH="900mbit" ;;
        no|NO)  CAKE_BANDWIDTH="" ;;
        *)      CAKE_BANDWIDTH="$X" ;;
    esac

    read -rp "Puerto del panel local              [8888]: " X
    PANEL_PORT="${X:-8888}"
    PANEL_DIR="/opt/panel-wisp"

    read -rp "Modo auto-update (aviso/tags)      [aviso]: " X
    AUTO_UPDATE_MODO="${X:-aviso}"

    echo ""
    echo "──────────────── Resumen ────────────────"
    echo "  WireGuard:   ${WG_IFACE} puerto ${WG_PORT} · ${WG_SUBNET} · servidor ${WG_SERVER_IP}"
    case "$DNS_PROVIDER" in
        controld)   echo "  DNS:         ControlD · resolver ${CONTROLD_RESOLVER_ID} · bootstrap ${CONTROLD_BOOTSTRAP_IP}" ;;
        adguard)    echo "  DNS:         AdGuard Home (en este VPS) · panel 127.0.0.1:${ADGUARD_PORT}" ;;
        technitium) echo "  DNS:         Technitium (en este VPS) · panel 127.0.0.1:${TECHNITIUM_PORT}" ;;
    esac
    echo "  CAKE:        ${CAKE_BANDWIDTH:-SIN LIMITE}"
    echo "  Panel:       127.0.0.1:${PANEL_PORT}"
    echo "  Auto-update: ${AUTO_UPDATE_MODO}"
    echo "─────────────────────────────────────────"
    read -rp "¿Correcto? [S/n]: " R
    if [[ "$R" =~ ^[nN] ]]; then
        echo "Nada guardado. Corre el script de nuevo."
        exit 1
    fi

    mkdir -p /etc/wisp
    cat > "$CONF" << CONFEOF
# Config central del gateway WISP — generada por el instalador $(date +%Y-%m-%d)
WG_PORT="${WG_PORT}"
WG_SUBNET="${WG_SUBNET}"
WG_SERVER_IP="${WG_SERVER_IP}"
WG_IFACE="${WG_IFACE}"
DNS_PROVIDER="${DNS_PROVIDER}"
CONTROLD_RESOLVER_ID="${CONTROLD_RESOLVER_ID}"
CONTROLD_BOOTSTRAP_IP="${CONTROLD_BOOTSTRAP_IP}"
ADGUARD_PORT="${ADGUARD_PORT}"
TECHNITIUM_PORT="${TECHNITIUM_PORT}"
CAKE_BANDWIDTH="${CAKE_BANDWIDTH}"
PANEL_PORT="${PANEL_PORT}"
PANEL_DIR="${PANEL_DIR}"
AUTO_UPDATE_MODO="${AUTO_UPDATE_MODO}"
CONFEOF
    chmod 600 "$CONF"
    echo "   Config guardada en $CONF (solo root la lee)."
fi

# La interfaz publica se detecta sola:
PUB_IFACE="${PUB_IFACE:-}"

echo "=============================================="
echo " Aprovisionamiento gateway WISP - v12 "
echo "=============================================="

# ------------------------------------------------------------------------------
# Deteccion de interfaz publica
# ------------------------------------------------------------------------------
if [ -z "$PUB_IFACE" ]; then
    PUB_IFACE=$(ip -o -4 route show to default | awk '{print $5}' | head -1)
fi
if [ -z "$PUB_IFACE" ]; then
    echo "ERROR: no se pudo detectar la interfaz publica. Edita PUB_IFACE a mano."
    exit 1
fi
echo "   Interfaz publica: ${PUB_IFACE}"
echo "   Tunel: ${WG_IFACE} | Rango: ${WG_SUBNET} | IP servidor: ${WG_SERVER_IP}"
case "${DNS_PROVIDER:-controld}" in
    adguard)    echo "   DNS: AdGuard Home (autohospedado)" ;;
    technitium) echo "   DNS: Technitium (autohospedado, servidor completo)" ;;
    *)          echo "   DNS: ControlD · resolver ${CONTROLD_RESOLVER_ID}" ;;
esac

# ------------------------------------------------------------------------------
# PASO 1 - Sistema base + parches automaticos
# ------------------------------------------------------------------------------
echo ">> [1/10] Actualizando sistema..."
apt update && apt full-upgrade -y
apt install -y curl wget gnupg2 sudo git ethtool whois irqbalance vnstat
systemctl enable --now irqbalance
systemctl enable --now vnstat
echo "   irqbalance activo (reparte IRQs de red entre cores) + vnstat (contabilidad)."

# unattended-upgrades: parches de SEGURIDAD automaticos (solo security repo,
# no actualiza versiones de programas). El VPS se parcha solo.
apt install -y unattended-upgrades
cat > /etc/apt/apt.conf.d/20auto-upgrades << 'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
EOF
systemctl enable --now unattended-upgrades
echo "   unattended-upgrades activo (parches de seguridad automaticos)."

# ------------------------------------------------------------------------------
# PASO 2 - WireGuard
# ------------------------------------------------------------------------------
echo ">> [2/10] Instalando WireGuard..."
apt install -y wireguard wireguard-tools

# ------------------------------------------------------------------------------
# PASO 3 - Sysctl: forwarding + tuning de red para gateway VPN
# ------------------------------------------------------------------------------
echo ">> [3/10] Configurando sysctl (forwarding + tuning)..."

# Config separada en /etc/sysctl.d/ (no ensuciamos /etc/sysctl.conf)
cat > /etc/sysctl.d/99-wisp-gateway.conf << 'EOF'
# --- Forwarding (obligatorio para el gateway) ---
net.ipv4.ip_forward = 1

# --- Buffers UDP grandes (WireGuard es puro UDP; evita drops con trafico alto) ---
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576

# --- fq_codel: menos bufferbloat = mejor latencia para los clientes ---
net.core.default_qdisc = fq_codel

# --- Conntrack: ~1000 clientes NATeados pueden generar cientos de miles
#     de conexiones simultaneas; con el default se llena y dropea en silencio ---
net.netfilter.nf_conntrack_max = 1048576

# --- Backlog mas alto para rafagas de paquetes ---
net.core.netdev_max_backlog = 16384
EOF

# nf_conntrack necesita el modulo cargado para aceptar su sysctl
modprobe nf_conntrack || true
echo "nf_conntrack" > /etc/modules-load.d/conntrack.conf

# Buckets de la tabla hash de conntrack (regla: max/4). Sin esto, con 1M de
# entradas las busquedas se degradan (cadenas largas en pocos buckets).
echo "options nf_conntrack hashsize=262144" > /etc/modprobe.d/nf_conntrack.conf
echo 262144 > /sys/module/nf_conntrack/parameters/hashsize 2>/dev/null || true

sysctl --system
echo "   Sysctl aplicado (forwarding, buffers UDP, fq_codel, conntrack)."

# ------------------------------------------------------------------------------
# PASO 4 - UDP GRO forwarding (mas throughput en WireGuard)
# ------------------------------------------------------------------------------
echo ">> [4/10] Habilitando UDP GRO forwarding en ${PUB_IFACE}..."

# Mejora recomendada para gateways/exit-nodes WireGuard: agrupa paquetes UDP
# forwardeados y reduce carga de CPU por paquete.
ethtool -K "${PUB_IFACE}" rx-udp-gro-forwarding on rx-gro-list off 2>/dev/null \
    && echo "   GRO forwarding activado." \
    || echo "   NOTA: la NIC/driver no soporta rx-udp-gro-forwarding (no es critico)."

# Persistencia al reboot via servicio systemd
cat > /etc/systemd/system/udp-gro-forwarding.service << EOF
[Unit]
Description=UDP GRO forwarding para gateway WireGuard
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/sbin/ethtool -K ${PUB_IFACE} rx-udp-gro-forwarding on rx-gro-list off
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable udp-gro-forwarding.service

# --- QoS: CAKE diffserv8 en wg0 ---
# CAKE lee el DSCP que marca nftables y encola en 8 niveles de prioridad.
# dual-dsthost = ademas reparte el ancho de banda de forma justa entre
# clientes (un cliente bajando torrents no ahoga a los demas).
# Necesita que wg0 exista: se arranca en los pasos manuales y solo al boot.
CAKE_OPTS="diffserv8 dual-dsthost"
if [ -n "${CAKE_BANDWIDTH}" ]; then
    CAKE_OPTS="bandwidth ${CAKE_BANDWIDTH} ${CAKE_OPTS}"
    echo "   CAKE con shaper a ${CAKE_BANDWIDTH} (la cola vive en CAKE = prioriza)."
else
    echo "   CAKE SIN limite de bandwidth (solo prioriza si wg0 se satura)."
fi
cat > /etc/systemd/system/qos-cake-wg0.service << EOF
[Unit]
Description=QoS CAKE diffserv8 en ${WG_IFACE}
After=wg-quick@${WG_IFACE}.service network-online.target

[Service]
Type=oneshot
ExecStart=/usr/sbin/tc qdisc replace dev ${WG_IFACE} root cake ${CAKE_OPTS}
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable qos-cake-wg0.service
echo "   Servicio CAKE creado (se arranca DESPUES de crear ${WG_IFACE})."

# ------------------------------------------------------------------------------
# PASO 5 - nftables COMPLETO
# (firewall + NAT + MSS clamp + anti-spoofing + aislamiento + DNS forzado)
# ------------------------------------------------------------------------------
echo ">> [5/10] Instalando y configurando nftables..."
apt install -y nftables

if [ -f /etc/nftables.conf ]; then
    cp /etc/nftables.conf /etc/nftables.conf.bak.$(date +%Y%m%d_%H%M%S)
fi

cat > /etc/nftables.conf << EOF
#!/usr/sbin/nft -f

flush ruleset

table inet filter {
    chain input {
        type filter hook input priority 0; policy drop;

        # Conexiones ya establecidas
        ct state established,related accept

        # Loopback
        iif lo accept

        # Descarta paquetes invalidos
        ct state invalid drop

        # ICMP (ping)
        ip protocol icmp accept
        ip6 nexthdr icmpv6 accept

        # SSH — puerto 22 (cambio a custom con cambiar-ssh.sh)
        tcp dport 22 accept

        # WireGuard
        udp dport ${WG_PORT} accept

        # DNS (ctrld) — solo desde el tunel
        iifname "${WG_IFACE}" udp dport 53 accept
        iifname "${WG_IFACE}" tcp dport 53 accept
    }

    chain forward {
        type filter hook forward priority 0; policy drop;

        ct state established,related accept
        ct state invalid drop

        # ===== MSS CLAMPING =====
        # El tunel tiene MTU 1420; sin esto, sitios que mandan paquetes
        # grandes se cuelgan o cargan a medias para los clientes.
        oifname "${WG_IFACE}" tcp flags syn tcp option maxseg size set rt mtu
        iifname "${WG_IFACE}" tcp flags syn tcp option maxseg size set rt mtu

        # ===== ANTI-SPOOFING =====
        # Solo se forwardea trafico del tunel cuyo origen sea del rango WG.
        # Un peer no puede inyectar paquetes con IP falsa.
        iifname "${WG_IFACE}" ip saddr != ${WG_SUBNET} drop

        # ===== AISLAMIENTO ENTRE CLIENTES =====
        # Los clientes del WISP no se ven entre si (peer -> peer bloqueado).
        iifname "${WG_IFACE}" oifname "${WG_IFACE}" drop

        # ===== PROTECCION DE REPUTACION - bloqueo de salida =====
        # SMTP saliente (spam) - causa #1 de blacklist
        iifname "${WG_IFACE}" tcp dport 25 drop
        iifname "${WG_IFACE}" tcp dport 465 drop
        iifname "${WG_IFACE}" tcp dport 587 drop
        iifname "${WG_IFACE}" tcp dport 2525 drop
        # Telnet saliente - gusanos IoT
        iifname "${WG_IFACE}" tcp dport 23 drop
        # SMB / NetBIOS - propagacion de malware
        iifname "${WG_IFACE}" tcp dport 135-139 drop
        iifname "${WG_IFACE}" tcp dport 445 drop
        iifname "${WG_IFACE}" udp dport 135-139 drop
        iifname "${WG_IFACE}" udp dport 445 drop
        # Bases de datos saliente
        iifname "${WG_IFACE}" tcp dport 1433 drop
        iifname "${WG_IFACE}" tcp dport 3306 drop
        # RDP saliente
        iifname "${WG_IFACE}" tcp dport 3389 drop
        # ===== FIN PROTECCION DE REPUTACION =====

        # Permitir que el tunel salga a internet
        iifname "${WG_IFACE}" oifname "${PUB_IFACE}" accept

        # Trafico de vuelta hacia el tunel
        iifname "${PUB_IFACE}" oifname "${WG_IFACE}" ct state established,related accept
    }

    chain output {
        type filter hook output priority 0; policy accept;
    }
}

table inet nat {
    # Redireccion DNS forzada — si un cliente pone 8.8.8.8, lo mandamos al resolver local (ctrld)
    chain prerouting {
        type nat hook prerouting priority -100;
        iifname "${WG_IFACE}" udp dport 53 redirect to :53
        iifname "${WG_IFACE}" tcp dport 53 redirect to :53
    }

    chain postrouting {
        type nat hook postrouting priority 100;
        ip saddr ${WG_SUBNET} oifname "${PUB_IFACE}" masquerade
    }
}

# =====================================================================
# QoS - MARCADO DSCP (CAKE en wg0 encola segun estas marcas)
# Prioridad: CS7 ping > CS6 juegos > CS4 social > CS2 streaming > CS0 resto
# EDITA LOS SETS segun los juegos/servicios de tus clientes.
# =====================================================================
table inet mangle {

    # Puertos UDP tipicos de juegos (Xbox/PSN, CoD, GTA, Steam, Fortnite...)
    set juegos_udp {
        type inet_service
        flags interval
        elements = { 3074, 3478-3480, 3658, 6672, 9295-9309, 27000-27100 }
    }

    # Puertos TCP de juegos
    set juegos_tcp {
        type inet_service
        flags interval
        elements = { 3074, 27015-27050 }
    }

    # Rangos IP de social media (Meta/FB/IG/WhatsApp + X/Twitter)
    # Actualizar con: whois -h whois.radb.net '!gAS32934' (Meta) / AS13414 (X)
    set redes_social {
        type ipv4_addr
        flags interval
        auto-merge
        elements = { 31.13.24.0/21, 31.13.64.0/18, 66.220.144.0/20,
                     69.63.176.0/20, 157.240.0.0/16, 179.60.192.0/22,
                     185.60.216.0/22, 104.244.40.0/21, 199.16.156.0/22 }
    }

    # Rangos IP de streaming (Netflix/OCA). YouTube/Twitch comparten CDN
    # con todo Google/Amazon: no se pueden separar por IP y caen en "resto".
    set redes_streaming {
        type ipv4_addr
        flags interval
        auto-merge
        elements = { 23.246.0.0/18, 37.77.184.0/21, 45.57.0.0/17,
                     108.175.32.0/20, 198.38.96.0/19, 198.45.48.0/20 }
    }

    chain forward {
        type filter hook forward priority mangle; policy accept;

        # 1) PING / ICMP — maxima prioridad
        ip protocol icmp ip dscp set cs7

        # 2) JUEGOS — por puerto, ambas direcciones
        udp sport @juegos_udp ip dscp set cs6
        udp dport @juegos_udp ip dscp set cs6
        tcp sport @juegos_tcp ip dscp set cs6
        tcp dport @juegos_tcp ip dscp set cs6

        # 3) SOCIAL — por rango IP, ambas direcciones
        ip saddr @redes_social ip dscp set cs4
        ip daddr @redes_social ip dscp set cs4

        # 4) STREAMING — por rango IP, ambas direcciones
        ip saddr @redes_streaming ip dscp set cs2
        ip daddr @redes_streaming ip dscp set cs2

        # 5) RESTO — queda en CS0 (best effort), no hace falta regla
    }
}
EOF

if nft -c -f /etc/nftables.conf; then
    systemctl enable nftables
    systemctl restart nftables
    echo "   nftables aplicado (MSS clamp + anti-spoofing + aislamiento incluidos)."
else
    echo "   ERROR: validacion de nftables fallo."
    LAST_BAK=$(ls -t /etc/nftables.conf.bak.* 2>/dev/null | head -1)
    if [ -n "$LAST_BAK" ]; then
        cp "$LAST_BAK" /etc/nftables.conf
        echo "   Se restauro el backup anterior."
    fi
    exit 1
fi

# ------------------------------------------------------------------------------
# PASO 5b - Auto-actualizacion de sets de IPs de QoS (RADB por ASN)
# ------------------------------------------------------------------------------
echo ">> [5b] Configurando auto-actualizacion de IPs de QoS..."

cat > /usr/local/sbin/actualizar-qos-ips.sh << 'UPDEOF'
#!/bin/bash
# Actualiza los sets de QoS (redes_social / redes_streaming) consultando
# RADB por ASN. Se corre semanal (timer) y tras cada restart de nftables.
set -u

# ASNs a consultar — edita aqui si quieres agregar mas empresas:
ASN_SOCIAL="AS32934 AS13414"       # Meta (FB/IG/WhatsApp), X/Twitter
ASN_STREAMING="AS2906 AS40027"     # Netflix (backbone + streaming)

MIN_PREFIJOS=5   # proteccion: si RADB devuelve menos, NO se toca el set actual
TMP=$(mktemp)
trap 'rm -f "$TMP"' EXIT

obtener() {
    local salida=""
    for asn in $1; do
        salida+="$(whois -h whois.radb.net -- "-i origin ${asn}" 2>/dev/null \
                   | awk '/^route:/ {print $2}')"$'\n'
    done
    echo "$salida" | grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}$' | sort -u
}

aplicar() {
    local set_name="$1" prefijos="$2"
    local n
    n=$(echo "$prefijos" | grep -c . || true)
    if [ "$n" -lt "$MIN_PREFIJOS" ]; then
        echo "AVISO: solo $n prefijos para $set_name (¿RADB caido?). Set actual intacto."
        return 0
    fi
    # flush + add en un solo nft -f = transaccion atomica (nunca queda vacio)
    {
        echo "flush set inet mangle $set_name"
        echo "add element inet mangle $set_name { $(echo "$prefijos" | paste -sd, -) }"
    } > "$TMP"
    if nft -f "$TMP"; then
        echo "$set_name actualizado: $n prefijos."
    else
        echo "ERROR aplicando $set_name; el set anterior sigue activo."
    fi
}

aplicar redes_social    "$(obtener "$ASN_SOCIAL")"
aplicar redes_streaming "$(obtener "$ASN_STREAMING")"
UPDEOF
chmod +x /usr/local/sbin/actualizar-qos-ips.sh

# Servicio: corre el actualizador. PartOf=nftables -> si reinicias el firewall
# (que resetea los sets a los valores estaticos del .conf), esto los refresca solo.
cat > /etc/systemd/system/actualizar-qos-ips.service << 'EOF'
[Unit]
Description=Actualiza sets de IPs de QoS desde RADB
After=nftables.service network-online.target
PartOf=nftables.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/actualizar-qos-ips.sh

[Install]
WantedBy=multi-user.target
EOF

# Timer: semanal, con delay aleatorio para no clavar RADB en punto
cat > /etc/systemd/system/actualizar-qos-ips.timer << 'EOF'
[Unit]
Description=Actualizacion semanal de IPs de QoS

[Timer]
OnCalendar=weekly
RandomizedDelaySec=1h
Persistent=true

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable actualizar-qos-ips.service
systemctl enable --now actualizar-qos-ips.timer

# Primera corrida ya mismo (no fatal si RADB no responde ahora)
/usr/local/sbin/actualizar-qos-ips.sh || true
echo "   Actualizador de IPs activo (semanal + tras cada restart de nftables)."

# ------------------------------------------------------------------------------
# PASO 6 - DNS filtrado: ControlD (ctrld) o AdGuard Home, segun DNS_PROVIDER
# ------------------------------------------------------------------------------
if [ "${DNS_PROVIDER:-controld}" = "technitium" ]; then
# ---------------------------- Technitium DNS ----------------------------------
echo ">> [6/10] Instalando Technitium DNS Server (servidor DNS completo)..."
echo "   NOTA: instala tambien el runtime .NET (varios cientos de MB)."

# Debian trae systemd-resolved ocupando el 53 en algunos VPS: liberarlo
systemctl disable --now systemd-resolved 2>/dev/null || true

# Instalador oficial (detecta arquitectura, instala .NET y crea el servicio)
curl -sSL https://download.technitium.com/dns/install.sh | bash

# Configuracion inicial por variables de entorno: DNS solo en la IP del tunel,
# panel SOLO en localhost (se accede por tunel SSH, como el resto).
mkdir -p /etc/systemd/system/dns.service.d
cat > /etc/systemd/system/dns.service.d/gateway-wisp.conf << EOF
[Service]
# DNS escuchando solo en el tunel
Environment=DNS_SERVER_LOCAL_ADDRESSES=${WG_SERVER_IP}
# Panel web solo en localhost
Environment=DNS_SERVER_WEB_SERVICE_LOCAL_ADDRESSES=127.0.0.1
Environment=DNS_SERVER_WEB_SERVICE_HTTP_PORT=${TECHNITIUM_PORT:-5380}
Environment=DNS_SERVER_WEB_SERVICE_ENABLE_HTTPS=false
# Reenvio cifrado (DoH) hacia arriba
Environment=DNS_SERVER_FORWARDERS=https://cloudflare-dns.com/dns-query,https://dns.quad9.net/dns-query
Environment=DNS_SERVER_FORWARDER_PROTOCOL=Https
Environment=DNS_SERVER_RECURSION=UseSpecifiedNetworks
Environment=DNS_SERVER_RECURSION_ALLOWED_NETWORKS=${WG_SUBNET},127.0.0.1
# Listas de bloqueo base
Environment=DNS_SERVER_BLOCK_LIST_URLS=https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts,https://adaway.org/hosts.txt
EOF

systemctl daemon-reload
systemctl enable dns 2>/dev/null || true
echo "   Technitium instalado (servicio: dns)."
echo "   NOTA: se arranca DESPUES de crear ${WG_IFACE} (necesita su IP)."
echo "   El primer acceso al panel te pide crear la contrasena de admin."

elif [ "${DNS_PROVIDER:-controld}" = "adguard" ]; then
# ---------------------------- AdGuard Home ------------------------------------
echo ">> [6/10] Instalando AdGuard Home (DNS filtrado autohospedado)..."

# Instalador oficial (detecta arquitectura, crea el servicio systemd)
curl -sSL https://raw.githubusercontent.com/AdguardTeam/AdGuardHome/master/scripts/install.sh | sh -s -- -v

# Configuracion inicial: escucha DNS en la IP del tunel, panel SOLO en localhost
# (se accede por tunel SSH, igual que WGDashboard y Netdata).
systemctl stop AdGuardHome 2>/dev/null || true
mkdir -p /opt/AdGuardHome
cat > /opt/AdGuardHome/AdGuardHome.yaml << EOF
http:
  address: 127.0.0.1:${ADGUARD_PORT:-3000}
dns:
  bind_hosts:
    - ${WG_SERVER_IP}
  port: 53
  upstream_dns:
    - https://dns.cloudflare.com/dns-query
    - https://dns.quad9.net/dns-query
  bootstrap_dns:
    - 1.1.1.1
    - 9.9.9.9
  cache_size: 67108864
  cache_ttl_min: 60
  ratelimit: 0
  enable_dnssec: true
filtering:
  protection_enabled: true
  filtering_enabled: true
  parental_enabled: false
  safe_search:
    enabled: false
filters:
  - enabled: true
    url: https://adguardteam.github.io/HostlistsRegistry/assets/filter_1.txt
    name: AdGuard DNS filter
    id: 1
  - enabled: true
    url: https://adguardteam.github.io/HostlistsRegistry/assets/filter_2.txt
    name: AdAway Default Blocklist
    id: 2
schema_version: 27
EOF
chown root:root /opt/AdGuardHome/AdGuardHome.yaml
chmod 0640 /opt/AdGuardHome/AdGuardHome.yaml

systemctl enable AdGuardHome
echo "   AdGuard Home instalado."
echo "   NOTA: se arranca DESPUES de crear ${WG_IFACE} (necesita su IP)."
echo "   El primer acceso al panel te pide crear usuario y contrasena."

else
# ------------------------------ ControlD --------------------------------------
echo ">> [6/10] Instalando ctrld (cliente nativo ControlD)..."

# Instalador oficial de ControlD (baja el binario correcto para la arquitectura)
sh -c 'sh -c "$(curl -sL https://api.controld.com/dl)"'

# Crear el config file de ctrld apuntando a TU resolver, escuchando en la IP del tunel
mkdir -p /etc/controld
cat > /etc/controld/ctrld.toml << EOF
[service]
  cache_enable = true
  cache_size = 65536

[listener]

  [listener.0]
    ip = '${WG_SERVER_IP}'
    port = 53

[network]

  [network.0]
    cidrs = ["${WG_SUBNET}"]
    name = "Tunel WireGuard"

[upstream]

  [upstream.0]
    bootstrap_ip = "${CONTROLD_BOOTSTRAP_IP}"
    endpoint = "https://dns.controld.com/${CONTROLD_RESOLVER_ID}"
    name = "ControlD"
    timeout = 5000
    type = "doh3"
EOF

echo "   Config de ctrld creada (listener en ${WG_SERVER_IP}:53, DoH3 -> ControlD)."
echo "   NOTA: ctrld se arranca DESPUES de crear ${WG_IFACE} (necesita la IP del tunel)."
fi

# ------------------------------------------------------------------------------
# PASO 7 - WGDashboard
# ------------------------------------------------------------------------------
echo ">> [7/10] Instalando WGDashboard..."
cd /root
if [ ! -d "/root/WGDashboard" ]; then
    git clone https://github.com/donaldzou/WGDashboard.git
fi
cd /root/WGDashboard/src
chmod +x wgd.sh
./wgd.sh install
./wgd.sh start
echo "   WGDashboard en el puerto 10086 (via tunel SSH)."

# ------------------------------------------------------------------------------
# PASO 8 - CrowdSec + bouncer nftables (arranque correcto + metricas)
# ------------------------------------------------------------------------------
echo ">> [8/10] Instalando CrowdSec..."
curl -s https://install.crowdsec.net | sh
apt install -y crowdsec

cscli collections install crowdsecurity/linux || true
cscli collections install crowdsecurity/sshd || true
cscli collections install crowdsecurity/base-http-scenarios || true
cscli scenarios install crowdsecurity/http-probing || true
cscli collections install crowdsecurity/iptables || true

# --- Metricas Prometheus de CrowdSec (agente) ---
if grep -q "^prometheus:" /etc/crowdsec/config.yaml; then
    sed -i '/^prometheus:/,/^[a-z]/ s/enabled: false/enabled: true/' /etc/crowdsec/config.yaml
fi

# CrowdSec corriendo ANTES de instalar el bouncer (auto-registro contra la LAPI)
systemctl enable crowdsec
systemctl restart crowdsec
sleep 5

echo ">> [8/10] Instalando bouncer nftables..."
apt install -y crowdsec-firewall-bouncer-nftables

# --- Metricas Prometheus del bouncer (127.0.0.1:60601) ---
BOUNCER_CFG="/etc/crowdsec/bouncers/crowdsec-firewall-bouncer.yaml"
if [ -f "$BOUNCER_CFG" ]; then
    sed -i '/^prometheus:/,/listen_port/ s/enabled: false/enabled: true/' "$BOUNCER_CFG"
fi

# --- Drop-in systemd: el bouncer vive atado a nftables ---
# "flush ruleset" borra las tablas crowdsec; con esto, cada restart de
# nftables reinicia el bouncer y se re-aplican los baneos.
mkdir -p /etc/systemd/system/crowdsec-firewall-bouncer.service.d
cat > /etc/systemd/system/crowdsec-firewall-bouncer.service.d/nftables.conf << 'EOF'
[Unit]
PartOf=nftables.service
After=nftables.service crowdsec.service
EOF
systemctl daemon-reload

systemctl enable --now crowdsec-firewall-bouncer
systemctl restart crowdsec-firewall-bouncer

# Verificacion
sleep 3
echo ""
echo "   --- Verificacion del bouncer ---"
if systemctl is-active --quiet crowdsec-firewall-bouncer; then
    echo "   Bouncer: ACTIVO"
else
    echo "   ATENCION: el bouncer NO esta corriendo. Revisa:"
    echo "   journalctl -u crowdsec-firewall-bouncer -n 30"
fi
cscli bouncers list || true
if nft list tables | grep -q crowdsec; then
    echo "   Tablas nftables de crowdsec: PRESENTES"
else
    echo "   ATENCION: no se ven las tablas crowdsec en nftables."
fi

# ------------------------------------------------------------------------------
# PASO 9 - Netdata (+ scrape de metricas Prometheus de CrowdSec)
# ------------------------------------------------------------------------------
echo ">> [9/10] Instalando Netdata..."
curl -Ss https://get.netdata.cloud/kickstart.sh > /tmp/netdata-kickstart.sh
sh /tmp/netdata-kickstart.sh --non-interactive || echo "   Revisa Netdata manualmente si fallo."

NETDATA_GODIR=""
if [ -d /etc/netdata ]; then
    NETDATA_GODIR="/etc/netdata/go.d"
elif [ -d /opt/netdata/etc/netdata ]; then
    NETDATA_GODIR="/opt/netdata/etc/netdata/go.d"
fi

if [ -n "$NETDATA_GODIR" ]; then
    mkdir -p "$NETDATA_GODIR"
    cat > "$NETDATA_GODIR/prometheus.conf" << 'EOF'
jobs:
  - name: crowdsec
    url: http://127.0.0.1:6060/metrics

  - name: crowdsec_bouncer
    url: http://127.0.0.1:60601/metrics
EOF
    systemctl restart netdata || true
    echo "   Netdata configurado para scrapear CrowdSec (6060) y bouncer (60601)."
else
    echo "   ATENCION: no encontre el dir de config de Netdata; agrega el scrape a mano."
fi

# ------------------------------------------------------------------------------
# PASO 9b - Backup diario de configuraciones
# ------------------------------------------------------------------------------
echo ">> [9b] Configurando backups diarios..."

cat > /usr/local/sbin/backup-wisp.sh << 'BKEOF'
#!/bin/bash
# Backup de configs criticas del gateway. Con esto + el script de setup,
# el VPS se reconstruye completo en minutos.
set -u
DEST=/var/backups/wisp
mkdir -p "$DEST"
FECHA=$(date +%Y%m%d_%H%M%S)
tar czf "$DEST/wisp-config-${FECHA}.tar.gz" --ignore-failed-read \
    /etc/wireguard \
    /etc/nftables.conf \
    /etc/controld \
    /etc/crowdsec \
    /etc/sysctl.d/99-wisp-gateway.conf \
    /etc/systemd/system/qos-cake-wg0.service \
    /etc/systemd/system/actualizar-qos-ips.service \
    /etc/systemd/system/actualizar-qos-ips.timer \
    /usr/local/sbin/actualizar-qos-ips.sh \
    /root/WGDashboard/src/db 2>/dev/null
# Rotacion: conserva los ultimos 14
ls -t "$DEST"/wisp-config-*.tar.gz 2>/dev/null | tail -n +15 | xargs -r rm -f
echo "Backup: $DEST/wisp-config-${FECHA}.tar.gz"
BKEOF
chmod +x /usr/local/sbin/backup-wisp.sh

cat > /etc/systemd/system/backup-wisp.service << 'EOF'
[Unit]
Description=Backup de configs del gateway WISP

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/backup-wisp.sh
EOF

cat > /etc/systemd/system/backup-wisp.timer << 'EOF'
[Unit]
Description=Backup diario de configs del gateway WISP

[Timer]
OnCalendar=*-*-* 03:30:00
RandomizedDelaySec=15m
Persistent=true

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable --now backup-wisp.timer
echo "   Backup diario 03:30 en /var/backups/wisp (rotacion 14 dias)."
echo "   IMPORTANTE: copia esos tar FUERA del VPS (rsync al homelab por el tunel)."

# ------------------------------------------------------------------------------
# PASO 9c - Panel de control local (localhost:8888)
# Dashboard con enlaces a todos los paneles (WGDashboard, Netdata, CrowdSec
# Console, ControlD, endpoints Prometheus) + LEDs de estado en vivo.
# Solo escucha en 127.0.0.1: se accede via tunel SSH.
# ------------------------------------------------------------------------------
echo ">> [9c] Instalando panel de control local..."

PANEL_DIR="${PANEL_DIR:-/opt/panel-wisp}"
PANEL_PORT="${PANEL_PORT:-8888}"

echo "=============================================="
echo " Instalando panel de control del gateway "
echo "=============================================="

mkdir -p "$PANEL_DIR"

cat > "$PANEL_DIR/index.html" << 'HTMLEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gateway WISP — Panel</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
<style>
  :root{
    --fondo:#0D1A22;
    --panel:#132630;
    --panel-alto:#17303C;
    --linea:#1F3B49;
    --texto:#D8E4EA;
    --texto-suave:#7C97A6;
    --ambar:#E8A33D;
    --verde:#3DC97C;
    --rojo:#E05C4B;
    --wg:#4FC3C8;
    --cs:#E0704B;
    --nd:#5BC466;
    --cd:#9B7FE0;
  }
  *{margin:0;padding:0;box-sizing:border-box}
  body{
    background:var(--fondo);
    color:var(--texto);
    font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
    min-height:100vh;
    padding:0 20px 48px;
  }
  /* ---- barra superior tipo rack ---- */
  header{
    max-width:960px;margin:0 auto;
    padding:26px 0 18px;
    display:flex;align-items:baseline;justify-content:space-between;
    border-bottom:2px solid var(--ambar);
  }
  .titulo{
    font-family:"Barlow Condensed",sans-serif;
    font-weight:700;font-size:clamp(26px,4.5vw,38px);
    letter-spacing:.06em;text-transform:uppercase;
  }
  .titulo span{color:var(--ambar)}
  .reloj{
    font-family:"JetBrains Mono",monospace;
    font-size:13px;color:var(--texto-suave);
  }
  /* ---- rejilla de tarjetas rack ---- */
  main{max-width:960px;margin:0 auto}
  .seccion{
    font-family:"Barlow Condensed",sans-serif;
    font-weight:600;font-size:15px;letter-spacing:.18em;
    text-transform:uppercase;color:var(--texto-suave);
    margin:30px 0 12px;
  }
  .rejilla{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}
  a.tarjeta{
    display:flex;align-items:stretch;gap:0;
    background:var(--panel);
    border:1px solid var(--linea);
    border-radius:10px;
    text-decoration:none;color:var(--texto);
    overflow:hidden;
    transition:transform .12s ease, background .12s ease;
  }
  a.tarjeta:hover,a.tarjeta:focus-visible{background:var(--panel-alto);transform:translateY(-2px)}
  a.tarjeta:focus-visible{outline:2px solid var(--ambar);outline-offset:2px}
  .franja{width:5px;flex:none}
  .cuerpo{padding:16px 16px 14px;flex:1;min-width:0}
  .nombre{
    font-family:"Barlow Condensed",sans-serif;
    font-weight:600;font-size:20px;letter-spacing:.04em;
    display:flex;align-items:center;gap:9px;
  }
  .led{
    width:9px;height:9px;border-radius:50%;flex:none;
    background:var(--texto-suave);opacity:.45;
    transition:background .3s, opacity .3s, box-shadow .3s;
  }
  .led.ok{background:var(--verde);opacity:1;box-shadow:0 0 7px var(--verde)}
  .led.fail{background:var(--rojo);opacity:1}
  .desc{font-size:13px;color:var(--texto-suave);margin-top:5px;line-height:1.45}
  .puerto{
    font-family:"JetBrains Mono",monospace;
    font-weight:700;font-size:15px;
    padding:16px 14px;flex:none;
    display:flex;align-items:center;
    color:var(--texto-suave);
    border-left:1px dashed var(--linea);
  }
  /* ---- bloque del tunel ---- */
  .tunel{
    margin-top:34px;
    background:var(--panel);
    border:1px solid var(--linea);
    border-left:5px solid var(--ambar);
    border-radius:10px;
    padding:16px 18px;
  }
  .tunel h2{
    font-family:"Barlow Condensed",sans-serif;
    font-weight:600;font-size:17px;letter-spacing:.08em;text-transform:uppercase;
    margin-bottom:10px;
  }
  .comando{
    display:flex;gap:10px;align-items:flex-start;
  }
  code{
    font-family:"JetBrains Mono",monospace;
    font-size:12.5px;line-height:1.7;
    color:var(--texto);
    background:var(--fondo);
    border:1px solid var(--linea);
    border-radius:7px;
    padding:11px 13px;
    flex:1;overflow-x:auto;white-space:pre;
    display:block;
  }
  button{
    font-family:"Barlow Condensed",sans-serif;
    font-weight:600;font-size:14px;letter-spacing:.06em;text-transform:uppercase;
    background:var(--ambar);color:#20180A;
    border:none;border-radius:7px;
    padding:10px 16px;cursor:pointer;flex:none;
  }
  button:hover{filter:brightness(1.1)}
  .nota{font-size:12.5px;color:var(--texto-suave);margin-top:10px;line-height:1.5}
  .nota b{color:var(--texto);font-weight:600}
  /* ---- comandos rapidos ---- */
  .chuleta{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:10px}
  .cmd{
    background:var(--panel);border:1px solid var(--linea);border-radius:8px;
    padding:11px 13px;
  }
  .cmd .que{font-size:12px;color:var(--texto-suave);margin-bottom:4px}
  .cmd .como{font-family:"JetBrains Mono",monospace;font-size:12.5px;color:var(--wg)}
  @media (prefers-reduced-motion: reduce){
    a.tarjeta{transition:none}
  }
</style>
</head>
<body>

<header>
  <div class="titulo">Gateway <span>WISP</span></div>
  <div class="reloj" id="reloj"></div>
</header>

<main>
  <div class="seccion">Paneles locales — via túnel SSH</div>
  <div class="rejilla">
    <a class="tarjeta" href="http://localhost:10086" target="_blank" rel="noopener">
      <div class="franja" style="background:var(--wg)"></div>
      <div class="cuerpo">
        <div class="nombre"><span class="led" data-chequea="http://localhost:10086"></span>WGDashboard</div>
        <div class="desc">Peers WireGuard: crear clientes, ver tráfico y handshakes.</div>
      </div>
      <div class="puerto">:10086</div>
    </a>
    <a class="tarjeta" href="http://localhost:19999" target="_blank" rel="noopener">
      <div class="franja" style="background:var(--nd)"></div>
      <div class="cuerpo">
        <div class="nombre"><span class="led" data-chequea="http://localhost:19999"></span>Netdata</div>
        <div class="desc">CPU, red, conntrack y métricas de CrowdSec en tiempo real.</div>
      </div>
      <div class="puerto">:19999</div>
    </a>
  </div>

  <div class="seccion">Paneles en la nube</div>
  <div class="rejilla">
    <a class="tarjeta" href="https://app.crowdsec.net" target="_blank" rel="noopener">
      <div class="franja" style="background:var(--cs)"></div>
      <div class="cuerpo">
        <div class="nombre">CrowdSec Console</div>
        <div class="desc">Alertas, IPs baneadas y contexto CTI de cada atacante.</div>
      </div>
      <div class="puerto">nube</div>
    </a>
    <a class="tarjeta" href="https://controld.com/dashboard" target="_blank" rel="noopener">
      <div class="franja" style="background:var(--cd)"></div>
      <div class="cuerpo">
        <div class="nombre">ControlD</div>
        <div class="desc">Filtrado DNS: reglas, estadísticas y clientes del resolver.</div>
      </div>
      <div class="puerto">nube</div>
    </a>
  </div>

  <div class="seccion">Endpoints de métricas — texto plano (los lee Netdata)</div>
  <div class="rejilla">
    <a class="tarjeta" href="http://localhost:6060/metrics" target="_blank" rel="noopener">
      <div class="franja" style="background:var(--cs)"></div>
      <div class="cuerpo">
        <div class="nombre"><span class="led" data-chequea="http://localhost:6060/metrics"></span>CrowdSec · Prometheus</div>
        <div class="desc">Métricas crudas del agente: parseos, escenarios, decisiones.</div>
      </div>
      <div class="puerto">:6060</div>
    </a>
    <a class="tarjeta" href="http://localhost:60601/metrics" target="_blank" rel="noopener">
      <div class="franja" style="background:var(--cs)"></div>
      <div class="cuerpo">
        <div class="nombre"><span class="led" data-chequea="http://localhost:60601/metrics"></span>Bouncer · Prometheus</div>
        <div class="desc">Métricas crudas del bouncer: paquetes dropeados, IPs activas.</div>
      </div>
      <div class="puerto">:60601</div>
    </a>
  </div>

  <div class="tunel">
    <h2>Túnel SSH — un solo comando abre todo</h2>
    <div class="comando">
      <code id="cmd-tunel">ssh -N -L 8888:127.0.0.1:8888 \
       -L 10086:127.0.0.1:10086 \
       -L 19999:127.0.0.1:19999 \
       -L 6060:127.0.0.1:6060 \
       -L 60601:127.0.0.1:60601 \
       usuario@IP_DEL_VPS</code>
      <button id="copiar">Copiar</button>
    </div>
    <div class="nota">Con el túnel abierto, este panel vive en <b>http://localhost:8888</b>.
    Los LEDs verdes indican qué servicios responden ahora mismo; un LED rojo
    significa que ese puerto no está en el túnel o el servicio está caído.</div>
  </div>

  <div class="seccion">Chuleta rápida — por SSH</div>
  <div class="chuleta">
    <div class="cmd"><div class="que">IPs baneadas ahora</div><div class="como">cscli decisions list</div></div>
    <div class="cmd"><div class="que">Tráfico del mes</div><div class="como">vnstat -m</div></div>
    <div class="cmd"><div class="que">Colas y prioridades QoS</div><div class="como">tc -s qdisc show dev wg0</div></div>
    <div class="cmd"><div class="que">Refrescar IPs de QoS</div><div class="como">sudo /usr/local/sbin/actualizar-qos-ips.sh</div></div>
    <div class="cmd"><div class="que">Estado del DNS filtrado</div><div class="como">dig verify.controld.com @10.40.40.1 +short</div></div>
    <div class="cmd"><div class="que">Backup manual</div><div class="como">sudo /usr/local/sbin/backup-wisp.sh</div></div>
  </div>
</main>

<script>
  // Reloj de cabecera
  function reloj(){
    var d = new Date();
    document.getElementById('reloj').textContent =
      d.toLocaleDateString('es', {weekday:'short', day:'2-digit', month:'short'}) +
      ' · ' + d.toLocaleTimeString('es');
  }
  reloj(); setInterval(reloj, 1000);

  // LEDs: chequeo real de cada servicio local (fetch no-cors: si responde,
  // aunque sea opaco, el tunel/servicio esta vivo; si lanza error, no).
  function chequear(led){
    var url = led.getAttribute('data-chequea');
    var ctl = new AbortController();
    var t = setTimeout(function(){ ctl.abort(); }, 2500);
    fetch(url, {mode:'no-cors', cache:'no-store', signal: ctl.signal})
      .then(function(){ led.classList.add('ok'); led.classList.remove('fail'); })
      .catch(function(){ led.classList.add('fail'); led.classList.remove('ok'); })
      .finally(function(){ clearTimeout(t); });
  }
  function chequearTodos(){
    document.querySelectorAll('.led[data-chequea]').forEach(chequear);
  }
  chequearTodos(); setInterval(chequearTodos, 30000);

  // Copiar comando del tunel
  document.getElementById('copiar').addEventListener('click', function(){
    var texto = document.getElementById('cmd-tunel').textContent;
    navigator.clipboard.writeText(texto).then(function(){
      var b = document.getElementById('copiar');
      b.textContent = 'Copiado';
      setTimeout(function(){ b.textContent = 'Copiar'; }, 1600);
    });
  });
</script>
</body>
</html>
HTMLEOF

echo "   HTML del panel escrito en ${PANEL_DIR}/index.html"

# ------------------------------------------------------------------------------
# Servicio: servidor HTTP minimo, SOLO en localhost
# ------------------------------------------------------------------------------
cat > /etc/systemd/system/panel-wisp.service << EOF
[Unit]
Description=Panel de control del gateway WISP (localhost:${PANEL_PORT})
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 -m http.server ${PANEL_PORT} --bind 127.0.0.1 --directory ${PANEL_DIR}
Restart=on-failure
# Endurecimiento basico del servicio
DynamicUser=yes
ProtectSystem=strict
ProtectHome=yes
NoNewPrivileges=yes
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now panel-wisp.service

sleep 1
if systemctl is-active --quiet panel-wisp.service; then
    echo "   Panel ACTIVO en http://127.0.0.1:${PANEL_PORT} (via tunel SSH)."
else
    echo "   ATENCION: el panel no arranco. Revisa: journalctl -u panel-wisp -n 30"
fi

# ------------------------------------------------------------------------------
# PASO 10 - Resumen
# ------------------------------------------------------------------------------
PUBIP=$(curl -4 -s ifconfig.me 2>/dev/null)

echo ""
echo "=============================================="
echo " Aprovisionamiento base completado (v12) "
echo "=============================================="
echo ""
echo "Interfaz publica: ${PUB_IFACE}"
echo "IP publica: ${PUBIP}"
case "${DNS_PROVIDER:-controld}" in
    adguard)
        echo "DNS: AdGuard Home (autohospedado) escuchando en ${WG_SERVER_IP}:53"
        echo "     Panel: http://localhost:${ADGUARD_PORT:-3000} (via tunel SSH)" ;;
    technitium)
        echo "DNS: Technitium (autohospedado) escuchando en ${WG_SERVER_IP}:53"
        echo "     Panel: http://localhost:${TECHNITIUM_PORT:-5380} (via tunel SSH)"
        echo "     OJO: runtime .NET — vigila la RAM con: systemctl status dns" ;;
    *)
        echo "DNS: ctrld (nativo ControlD) con DoH3, escuchando en ${WG_SERVER_IP}:53" ;;
esac
echo ""
echo "RENDIMIENTO:"
echo "  - MSS clamping activo (adios webs colgadas por MTU)"
echo "  - UDP GRO forwarding en ${PUB_IFACE} (persistente al reboot)"
echo "  - Buffers UDP 16MB, fq_codel, conntrack_max=262144"
echo ""
echo "QoS (DSCP + CAKE diffserv8):"
echo "  - Prioridad: ping > juegos > social > streaming > resto"
echo "  - Shaper CAKE: ${CAKE_BANDWIDTH:-SIN LIMITE} (variable CAKE_BANDWIDTH)"
echo "    Mide el throughput real con iperf3 y ajusta a ~90% de eso."
echo "  - Reparto justo de ancho de banda entre clientes (dual-dsthost)"
echo "  - IPs de social/streaming se AUTO-ACTUALIZAN cada semana desde RADB"
echo "    (y tras cada restart de nftables). Correr a mano:"
echo "    sudo /usr/local/sbin/actualizar-qos-ips.sh"
echo "  - Para agregar ASNs edita las variables al inicio de ese script"
echo "  - Los puertos de juegos siguen en /etc/nftables.conf (sets juegos_*)"
echo "  - IMPORTANTE: el cuello real esta en tus radios. Replica colas por"
echo "    DSCP en el MikroTik (el DSCP llega intacto dentro del tunel)."
echo ""
echo "ESCALA (~1000 clientes / ~1 Gbps):"
echo "  - conntrack: 1M entradas, 256K buckets"
echo "  - irqbalance repartiendo IRQs de red entre cores"
case "${DNS_PROVIDER:-controld}" in
    adguard)    echo "  - Cache DNS AdGuard: 64 MB" ;;
    technitium) echo "  - Cache DNS Technitium (por defecto del servidor)" ;;
    *)          echo "  - Cache DNS ctrld: 65536 registros" ;;
esac
echo "  - vnstat contando trafico: vnstat -m (mensual) / vnstat -d (diario)"
echo "  - Backup diario 03:30 -> /var/backups/wisp (COPIALO fuera del VPS)"
echo "  - VIGILA LA CPU a 1 Gbps: CAKE corre en un solo core por qdisc y el"
echo "    cifrado WireGuard usa varios. htop o Netdata te dicen si el VPS da."
echo ""
echo "PANEL DE CONTROL:"
echo "  - Todo en un solo lugar: http://localhost:8888 (via tunel SSH)"
echo "  - Tunel completo desde tu PC:"
echo "    ssh -N -L 8888:127.0.0.1:8888 -L 10086:127.0.0.1:10086 \\"
echo "           -L 19999:127.0.0.1:19999 -L 6060:127.0.0.1:6060 \\"
case "${DNS_PROVIDER:-controld}" in
    adguard)
        echo "           -L 60601:127.0.0.1:60601 -L ${ADGUARD_PORT:-3000}:127.0.0.1:${ADGUARD_PORT:-3000} \\"
        echo "           usuario@${PUBIP}" ;;
    technitium)
        echo "           -L 60601:127.0.0.1:60601 -L ${TECHNITIUM_PORT:-5380}:127.0.0.1:${TECHNITIUM_PORT:-5380} \\"
        echo "           usuario@${PUBIP}" ;;
    *)
        echo "           -L 60601:127.0.0.1:60601 usuario@${PUBIP}" ;;
esac
echo "  - Edita usuario@IP en /opt/panel-wisp/index.html para el boton Copiar"
echo ""
echo "SEGURIDAD:"
echo "  - Anti-spoofing: solo saddr ${WG_SUBNET} sale del tunel"
echo "  - Clientes aislados entre si (peer no ve a peer)"
echo "  - Parches de seguridad automaticos (unattended-upgrades)"
echo "  - Bouncer CrowdSec atado a nftables + metricas Prometheus en Netdata"
echo ""
echo "PASOS MANUALES EN ORDEN:"
echo ""
echo "  1. Conecta por tunel SSH al 10086 -> WGDashboard."
echo "     Crea la interfaz: nombre ${WG_IFACE}, puerto ${WG_PORT},"
echo "     Address: ${WG_SERVER_IP}/24   (MASCARA /24, no /32!)"
echo ""
echo "  2. Habilita arranque automatico de WireGuard y arranca el QoS:"
echo "     systemctl enable wg-quick@${WG_IFACE}"
echo "     systemctl start qos-cake-wg0"
echo "     tc -s qdisc show dev ${WG_IFACE}   (debe decir 'cake ... diffserv8')"
echo ""
if [ "${DNS_PROVIDER:-controld}" = "technitium" ]; then
echo "  3. Arranca Technitium (ya con ${WG_IFACE} creada y su IP asignada):"
echo "     systemctl start dns"
echo "     systemctl status dns --no-pager"
echo ""
echo "  4. Configura Technitium y verifica el filtrado:"
echo "     Entra por tunel SSH a http://localhost:${TECHNITIUM_PORT:-5380}"
echo "     (primer acceso: crea la contrasena de admin)"
echo "     dig google.com @${WG_SERVER_IP} +short        (debe resolver)"
echo "     dig doubleclick.net @${WG_SERVER_IP} +short   (debe dar 0.0.0.0)"
echo "     Vigila el consumo:  systemctl status dns --no-pager | grep Memory"
elif [ "${DNS_PROVIDER:-controld}" = "adguard" ]; then
echo "  3. Arranca AdGuard Home (ya con ${WG_IFACE} creada y su IP asignada):"
echo "     systemctl start AdGuardHome"
echo "     systemctl status AdGuardHome --no-pager"
echo ""
echo "  4. Configura AdGuard y verifica el filtrado:"
echo "     Entra por tunel SSH a http://localhost:${ADGUARD_PORT:-3000}"
echo "     (primer acceso: crea usuario y contrasena del panel)"
echo "     dig google.com @${WG_SERVER_IP} +short        (debe resolver)"
echo "     dig doubleclick.net @${WG_SERVER_IP} +short   (debe dar 0.0.0.0)"
else
echo "  3. Arranca ctrld (ya con ${WG_IFACE} creada y su IP asignada):"
echo "     ctrld start --config /etc/controld/ctrld.toml"
echo "     ctrld status    (debe decir que esta corriendo)"
echo ""
echo "  4. Verifica que el DNS filtra por DoH:"
echo "     dig verify.controld.com @${WG_SERVER_IP} +short   (debe resolver)"
echo "     dig doubleclick.net @${WG_SERVER_IP} +short        (debe dar 0.0.0.0)"
fi
echo ""
echo "  5. Crea los peers desde WGDashboard."
echo ""
echo "  6. (Opcional pero recomendado) Enrola en la Console de CrowdSec:"
echo "     Crea cuenta en app.crowdsec.net y corre:"
echo "     cscli console enroll <tu-token>"
echo ""
echo "  7. AL FINAL, cambia el puerto SSH:"
echo "     sudo bash cambiar-ssh.sh"
echo ""
echo "NOTA: proteccion de reputacion (puerto 25, etc.) YA integrada en el firewall."
echo "NOTA: SSH sigue aceptando password. Cuando quieras cerrarlo a solo llaves:"
echo "      PasswordAuthentication no  en /etc/ssh/sshd_config + systemctl restart ssh"
echo ""
# Si este setup corre desde el clon del repo, sincronizar con las plantillas
# (asi el panel con API, y cualquier mejora posterior del repo, quedan aplicados)
DIR_SCRIPT="$(cd "$(dirname "$0")" && pwd)"
if [ -f "${DIR_SCRIPT}/actualizar.sh" ]; then
    echo ">> Sincronizando con las plantillas del repo..."
    bash "${DIR_SCRIPT}/actualizar.sh" || echo "   AVISO: revisa actualizar.sh a mano."
fi

