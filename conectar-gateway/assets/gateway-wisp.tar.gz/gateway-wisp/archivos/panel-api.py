#!/usr/bin/env python3
# ==============================================================================
# panel-api.py — servidor del panel del gateway WISP (solo 127.0.0.1)
# ==============================================================================
# Sirve el HTML estatico del panel Y una mini-API local:
#   GET  /api/trafico           -> peers de WireGuard en vivo (tasas + totales)
#   GET  /api/update            -> version desplegada + estado del repo
#   POST /api/update/chequear   -> corre chequear-updates.sh y devuelve estado
# Configuracion por variables de entorno (las pone la unidad systemd):
#   WG_IFACE, PANEL_DIR, PANEL_PORT, REPO_DIR
# ==============================================================================

import json
import os
import subprocess
import threading
import time
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

WG_IFACE = os.environ.get("WG_IFACE", "wg0")
PANEL_DIR = os.environ.get("PANEL_DIR", "/opt/panel-wisp")
PANEL_PORT = int(os.environ.get("PANEL_PORT", "8888"))
REPO_DIR = os.environ.get("REPO_DIR", "/opt/gateway-wisp")

_lock = threading.Lock()
_prev = {}  # pubkey -> (timestamp, rx, tx) para calcular tasas
_vnstat_cache = {"t": 0.0, "mes": None}


def _correr(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout
    except FileNotFoundError:
        return 127, ""
    except subprocess.TimeoutExpired:
        return 124, ""


def _vnstat_mes():
    """Total del mes en curso segun vnstat (best-effort, cache 60s)."""
    ahora = time.time()
    if ahora - _vnstat_cache["t"] < 60:
        return _vnstat_cache["mes"]
    mes = None
    rc, out = _correr(["vnstat", "--json", "m"], timeout=8)
    if rc == 0 and out:
        try:
            datos = json.loads(out)
            iface = datos.get("interfaces", [{}])[0]
            meses = iface.get("traffic", {}).get("month", [])
            if meses:
                ultimo = meses[-1]
                mes = int(ultimo.get("rx", 0)) + int(ultimo.get("tx", 0))
        except (ValueError, KeyError, IndexError, TypeError):
            mes = None
    _vnstat_cache["t"] = ahora
    _vnstat_cache["mes"] = mes
    return mes


def api_trafico():
    rc, out = _correr(["wg", "show", WG_IFACE, "dump"], timeout=5)
    if rc != 0 or not out.strip():
        return {"interfaz": WG_IFACE, "activa": False, "peers": [],
                "total": {"rx": 0, "tx": 0, "rx_s": 0, "tx_s": 0},
                "mes_bytes": _vnstat_mes()}

    ahora = time.time()
    lineas = out.strip().split("\n")
    peers = []
    tot_rx = tot_tx = 0
    tot_rx_s = tot_tx_s = 0.0

    for linea in lineas[1:]:  # la primera linea es la interfaz
        c = linea.split("\t")
        if len(c) < 7:
            continue
        pub, endpoint, allowed = c[0], c[2], c[3]
        try:
            hs, rx, tx = int(c[4]), int(c[5]), int(c[6])
        except ValueError:
            continue

        rx_s = tx_s = 0.0
        with _lock:
            previo = _prev.get(pub)
            if previo:
                dt = ahora - previo[0]
                if dt > 0.5:
                    rx_s = max(0.0, (rx - previo[1]) / dt)
                    tx_s = max(0.0, (tx - previo[2]) / dt)
            _prev[pub] = (ahora, rx, tx)

        hs_hace = int(ahora - hs) if hs > 0 else None
        peers.append({
            "clave": pub[:10] + "…",
            "ip": allowed.split(",")[0] if allowed != "(none)" else "?",
            "endpoint": endpoint if endpoint != "(none)" else None,
            "rx": rx, "tx": tx,
            "rx_s": round(rx_s), "tx_s": round(tx_s),
            "handshake_hace_s": hs_hace,
            "en_linea": hs_hace is not None and hs_hace < 180,
        })
        tot_rx += rx
        tot_tx += tx
        tot_rx_s += rx_s
        tot_tx_s += tx_s

    peers.sort(key=lambda p: p["rx_s"] + p["tx_s"], reverse=True)
    return {
        "interfaz": WG_IFACE, "activa": True, "peers": peers,
        "en_linea": sum(1 for p in peers if p["en_linea"]),
        "total": {"rx": tot_rx, "tx": tot_tx,
                  "rx_s": round(tot_rx_s), "tx_s": round(tot_tx_s)},
        "mes_bytes": _vnstat_mes(),
    }


def api_update(chequear=False):
    if chequear:
        script = os.path.join(REPO_DIR, "auto-update", "chequear-updates.sh")
        if os.path.isfile(script):
            _correr(["bash", script], timeout=90)

    estado = {"disponible": None}
    try:
        with open(os.path.join(PANEL_DIR, "update.json")) as f:
            estado = json.load(f)
    except (OSError, ValueError):
        pass

    version = None
    try:
        with open("/etc/wisp/version") as f:
            version = f.read().strip()
    except OSError:
        rc, out = _correr(["git", "-C", REPO_DIR, "describe", "--tags", "--always"])
        if rc == 0:
            version = out.strip()
    estado["version_actual"] = version
    return estado


class Manejador(SimpleHTTPRequestHandler):
    def _json(self, datos, codigo=200):
        cuerpo = json.dumps(datos).encode()
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_GET(self):
        if self.path == "/api/trafico":
            return self._json(api_trafico())
        if self.path == "/api/update":
            return self._json(api_update())
        return super().do_GET()

    def do_POST(self):
        if self.path == "/api/update/chequear":
            return self._json(api_update(chequear=True))
        self.send_error(404)

    def log_message(self, *args):
        pass  # sin ruido en el journal por cada poll


def main():
    manejador = partial(Manejador, directory=PANEL_DIR)
    servidor = ThreadingHTTPServer(("127.0.0.1", PANEL_PORT), manejador)
    print(f"panel-api sirviendo {PANEL_DIR} + /api en 127.0.0.1:{PANEL_PORT}")
    servidor.serve_forever()


if __name__ == "__main__":
    main()
