#!/bin/bash
# Actualiza los sets de QoS (redes_social / redes_streaming) consultando
# RADB por ASN. Se corre semanal (timer) y tras cada restart de nftables.
set -u

# ASNs a consultar — edita aqui si quieres agregar mas empresas:
ASN_SOCIAL="AS32934 AS13414"       # Meta (FB/IG/WhatsApp), X/Twitter
ASN_STREAMING="AS2906 AS40027"     # Netflix (backbone + streaming)

MIN_PREFIJOS=5   # proteccion: si RADB devuelve menos, NO se toca el set actual
TMP=$(mktemp)
trap 'rm -f "$TMP"' EXIT

obtener() {
    local salida=""
    for asn in $1; do
        salida+="$(whois -h whois.radb.net -- "-i origin ${asn}" 2>/dev/null \
                   | awk '/^route:/ {print $2}')"$'\n'
    done
    echo "$salida" | grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}$' | sort -u
}

aplicar() {
    local set_name="$1" prefijos="$2"
    local n
    n=$(echo "$prefijos" | grep -c . || true)
    if [ "$n" -lt "$MIN_PREFIJOS" ]; then
        echo "AVISO: solo $n prefijos para $set_name (¿RADB caido?). Set actual intacto."
        return 0
    fi
    # flush + add en un solo nft -f = transaccion atomica (nunca queda vacio)
    {
        echo "flush set inet mangle $set_name"
        echo "add element inet mangle $set_name { $(echo "$prefijos" | paste -sd, -) }"
    } > "$TMP"
    if nft -f "$TMP"; then
        echo "$set_name actualizado: $n prefijos."
    else
        echo "ERROR aplicando $set_name; el set anterior sigue activo."
    fi
}

aplicar redes_social    "$(obtener "$ASN_SOCIAL")"
aplicar redes_streaming "$(obtener "$ASN_STREAMING")"
