#!/bin/bash
# Backup de configs criticas del gateway. Con esto + el script de setup,
# el VPS se reconstruye completo en minutos.
set -u
DEST=/var/backups/wisp
mkdir -p "$DEST"
FECHA=$(date +%Y%m%d_%H%M%S)
tar czf "$DEST/wisp-config-${FECHA}.tar.gz" --ignore-failed-read \
    /etc/wireguard \
    /etc/nftables.conf \
    /etc/controld \
    /etc/crowdsec \
    /etc/sysctl.d/99-wisp-gateway.conf \
    /etc/systemd/system/qos-cake-wg0.service \
    /etc/systemd/system/actualizar-qos-ips.service \
    /etc/systemd/system/actualizar-qos-ips.timer \
    /usr/local/sbin/actualizar-qos-ips.sh \
    /root/WGDashboard/src/db 2>/dev/null
# Rotacion: conserva los ultimos 14
ls -t "$DEST"/wisp-config-*.tar.gz 2>/dev/null | tail -n +15 | xargs -r rm -f
echo "Backup: $DEST/wisp-config-${FECHA}.tar.gz"
