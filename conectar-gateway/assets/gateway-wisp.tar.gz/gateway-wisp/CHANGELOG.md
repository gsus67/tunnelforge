# Changelog

Registro de cambios del gateway WISP. Las versiones del repo (v1.x) son
independientes de la numeración interna del script de aprovisionamiento.

## [v1.4.0] — 2026-08-15
### Añadido
- Tercera opción de DNS: **Technitium DNS Server** — servidor DNS completo
  autohospedado que además de filtrar resuelve zonas propias (nombres
  internos), split-horizon y DoH/DoT nativo.
- El asistente advierte que Technitium corre sobre .NET (~80-150 MB de RAM,
  ~150-250 MB de disco, 3-4× AdGuard) y pide confirmación explícita antes de
  elegirlo; si se rechaza, vuelve al menú.
- Technitium se instala escuchando DNS solo en la IP del túnel y su panel solo
  en localhost, con reenvío cifrado (DoH a Cloudflare/Quad9), recursión
  limitada a la subred del túnel y listas de bloqueo base.
- README: tabla comparativa de las tres opciones de DNS con consumo aproximado.

## [v1.3.0] — 2026-08-15
### Añadido
- **DNS a elegir en la instalación**: ControlD (filtrado en la nube vía ctrld
  con DoH3) o **AdGuard Home** (servidor propio en el VPS, tus reglas y tus
  logs, sin terceros). El asistente pregunta cuál usar.
- AdGuard se instala con panel solo en `localhost` (acceso por túnel SSH),
  listas de bloqueo base, caché de 64 MB, DNSSEC y upstreams cifrados
  (Cloudflare/Quad9 DoH).
- El panel del gateway muestra la tarjeta del DNS que corresponda, con LED
  de estado si es AdGuard.
### Cambiado
- README reescrito como documentación del proyecto: qué hace, qué instala,
  cómo desplegarlo en un servidor y cómo operarlo (antes eran notas de cómo
  subir el repo a GitHub).
- `actualizar.sh` respeta el proveedor: con AdGuard no pisa su configuración
  (se administra desde su panel), solo verifica que el servicio esté activo.
- El backup diario incluye `AdGuardHome.yaml`.

## [v1.2] — 2026-08-15
### Corregido
- README: URL del clon apuntaba a un placeholder; ahora usa el repo real
  y aclara que la carpeta destino es siempre `/opt/gateway-wisp`.
- README y `chequear-updates.sh`: ejemplos de tags usaban la numeración vieja
  del script (v11.x); ahora usan la del repo (v1.x).
- `setup-vps-wisp.sh`: línea de uso y mensajes del resumen arrastraban
  versiones internas viejas (v7/v10/v11); unificados.
- Añadido `.gitignore` (evita subir `__pycache__`, backups y el config local).

## [v1.1] — 2026-08-15
### Añadido
- Panel: sección de **tráfico en vivo** por peer (velocidad ↓↑ actual,
  totales, último handshake, LED de conexión) actualizada cada 3 s.
- Panel: tarjetas de resumen (bajada/subida ahora, transferido, mes vnstat,
  peers en línea).
- Panel: tarjeta de **actualizaciones** con versión desplegada, botón
  "Chequear ahora" y lista de cambios pendientes del repo.
- `panel-api.py`: mini-API local (solo 127.0.0.1) que sirve el panel y expone
  `/api/trafico` y `/api/update`.
### Cambiado
- La unidad `panel-wisp` ahora corre la API (sandbox systemd) en vez del
  http.server estático.
- `setup-vps-wisp.sh` auto-sincroniza con las plantillas del repo al terminar.

## [v1.0] — 2026-08-15
### Añadido
- Estructura inicial del repo (infraestructura como código).
- `setup-vps-wisp.sh`: instalador interactivo (variables por pantalla,
  sugerencias aleatorias de puerto y subred, guardado en `/etc/wisp/config.env`).
- `actualizar.sh`: re-aplica configs del repo de forma idempotente, con
  validación de nftables antes de tocar el firewall.
- `auto-update/`: chequeo periódico de updates (modos `aviso` y `tags`).
- Plantillas de nftables, ctrld, unidades systemd y panel de control.
- Scripts de QoS (auto-actualización de IPs por RADB) y backup diario.

<!--
Plantilla para la próxima versión — copiar arriba y rellenar:

## [v1.2] — AAAA-MM-DD
### Añadido
-
### Cambiado
-
### Corregido
-
-->
