#!/bin/bash
component_install(){
  need_root; need_debian; say '== QoS CAKE =='; ensure_network_conf; apt_install iproute2 whois
  local bw; bw=$(get_conf CAKE_BANDWIDTH); if ! valid_bandwidth "${bw:-}"; then while :; do bw=$(ask 'Límite CAKE (ej. 900Mbit; vacío = sin shaper)' ''); valid_bandwidth "$bw" && break; say 'Formato inválido.'; done; set_conf CAKE_BANDWIDTH "$bw"; fi
  local WG_IFACE CAKE_BANDWIDTH CAKE_OPTS; source "$GW_CONF"; CAKE_OPTS='diffserv8 dual-dsthost'; [ -n "${CAKE_BANDWIDTH:-}" ] && CAKE_OPTS="bandwidth ${CAKE_BANDWIDTH} ${CAKE_OPTS}"; export WG_IFACE CAKE_OPTS
  apt_install gettext-base
  envsubst '${WG_IFACE} ${CAKE_OPTS}' < "$GW_ROOT/systemd/qos-cake-wg0.service.tpl" > /etc/systemd/system/qos-cake-wg0.service
  install -m 0755 "$GW_ROOT/archivos/actualizar-qos-ips.sh" /usr/local/sbin/actualizar-qos-ips.sh
  install -m 0644 "$GW_ROOT/systemd/actualizar-qos-ips.service" /etc/systemd/system/actualizar-qos-ips.service
  install -m 0644 "$GW_ROOT/systemd/actualizar-qos-ips.timer" /etc/systemd/system/actualizar-qos-ips.timer
  systemctl daemon-reload; systemctl enable qos-cake-wg0.service; systemctl enable --now actualizar-qos-ips.timer
  mark qos; say 'QoS CAKE preparado. El servicio arrancará cuando exista la interfaz WireGuard.';
}
component_uninstall(){ need_root; systemctl disable --now qos-cake-wg0.service actualizar-qos-ips.timer 2>/dev/null || true; rm -f /etc/systemd/system/qos-cake-wg0.service /etc/systemd/system/actualizar-qos-ips.service /etc/systemd/system/actualizar-qos-ips.timer /usr/local/sbin/actualizar-qos-ips.sh; systemctl daemon-reload; unmark qos; say 'Integración QoS WISP retirada.'; }
