#!/bin/bash
component_install(){
  need_root; need_debian; say '== Backups y mantenimiento =='
  install -m 0755 "$GW_ROOT/archivos/backup-wisp.sh" /usr/local/sbin/backup-wisp.sh
  install -m 0644 "$GW_ROOT/systemd/backup-wisp.service" /etc/systemd/system/backup-wisp.service
  install -m 0644 "$GW_ROOT/systemd/backup-wisp.timer" /etc/systemd/system/backup-wisp.timer
  systemctl daemon-reload; systemctl enable --now backup-wisp.timer
  mark maintenance
  say 'Backup diario activado. El auto-update por Git NO se habilita en el paquete embebido; las actualizaciones se gestionan desde Gateway WISP Access.'
}
component_uninstall(){
  need_root; systemctl disable --now backup-wisp.timer 2>/dev/null || true
  rm -f /etc/systemd/system/backup-wisp.service /etc/systemd/system/backup-wisp.timer /usr/local/sbin/backup-wisp.sh
  systemctl daemon-reload; unmark maintenance; say 'Integración de backup automático retirada; los backups existentes se conservan.'
}
