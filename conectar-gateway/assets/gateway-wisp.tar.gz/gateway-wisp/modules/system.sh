#!/bin/bash
component_install(){
  need_root; need_debian; say '== Sistema base / tuning seguro =='; ensure_network_conf
  apt_install ca-certificates curl wget gnupg2 sudo git iproute2 ethtool whois irqbalance vnstat unattended-upgrades
  backup_file /etc/sysctl.d/99-wisp-gateway.conf sysctl-99-wisp-gateway.conf
  cat > /etc/sysctl.d/99-wisp-gateway.conf <<'CFG'
# Gestionado por Gateway WISP
net.ipv4.ip_forward = 1
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576
net.core.default_qdisc = fq_codel
net.netfilter.nf_conntrack_max = 1048576
net.core.netdev_max_backlog = 16384
CFG
  modprobe nf_conntrack 2>/dev/null || true
  printf 'nf_conntrack\n' > /etc/modules-load.d/conntrack.conf
  printf 'options nf_conntrack hashsize=262144\n' > /etc/modprobe.d/nf_conntrack.conf
  sysctl --system >/dev/null
  systemctl enable --now irqbalance vnstat 2>/dev/null || true
  cat > /etc/apt/apt.conf.d/20auto-upgrades <<'CFG'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
CFG
  systemctl enable --now unattended-upgrades 2>/dev/null || true
  local pub; pub=$(get_conf PUB_IFACE)
  if valid_iface "$pub"; then
    ethtool -K "$pub" rx-udp-gro-forwarding on rx-gro-list off 2>/dev/null || true
    cat > /etc/systemd/system/udp-gro-forwarding.service <<CFG
[Unit]
Description=UDP GRO forwarding para Gateway WISP
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/sbin/ethtool -K $pub rx-udp-gro-forwarding on rx-gro-list off
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
CFG
    systemctl daemon-reload; systemctl enable udp-gro-forwarding.service >/dev/null 2>&1 || true
  fi
  mark system; say 'Sistema base preparado. No se hizo full-upgrade automático.'
}
component_uninstall(){
  need_root
  if marked system; then
    rm -f /etc/sysctl.d/99-wisp-gateway.conf /etc/systemd/system/udp-gro-forwarding.service
    systemctl disable --now udp-gro-forwarding.service 2>/dev/null || true
    systemctl daemon-reload; sysctl --system >/dev/null 2>&1 || true
    say 'Tuning WISP retirado. No se desinstalan paquetes ni se revierten ajustes ajenos.'
  fi
  unmark system
}
