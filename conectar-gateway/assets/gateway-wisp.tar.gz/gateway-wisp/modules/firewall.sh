#!/bin/bash
component_install(){
  need_root; need_debian; say '== Firewall / NAT nftables =='; ensure_network_conf
  apt_install nftables gettext-base
  local sshp; sshp=$(current_ssh_port); set_conf SSH_PORT "$sshp"
  mkdir -p /etc/wisp/firewall.d
  [ -f /etc/wisp/firewall.d/90-local-ports.nft ] || printf '# Reglas persistentes administradas por Gateway WISP Access\n' > /etc/wisp/firewall.d/90-local-ports.nft
  local WG_PORT WG_SUBNET WG_SERVER_IP WG_IFACE PUB_IFACE SSH_PORT
  # shellcheck disable=SC1090
  source "$GW_CONF"
  export WG_PORT WG_SUBNET WG_SERVER_IP WG_IFACE PUB_IFACE SSH_PORT
  local vars='${WG_PORT} ${WG_SUBNET} ${WG_SERVER_IP} ${WG_IFACE} ${PUB_IFACE} ${SSH_PORT}' tmp
  tmp=$(mktemp); envsubst "$vars" < "$GW_ROOT/plantillas/nftables.conf.tpl" > "$tmp"
  nft -c -f "$tmp" || { rm -f "$tmp"; say 'ERROR: nftables no pasó la validación. No se tocó el firewall.'; exit 1; }
  backup_file /etc/nftables.conf nftables.conf
  install -m 0644 "$tmp" /etc/nftables.conf; rm -f "$tmp"
  systemctl enable nftables; systemctl restart nftables
  mark firewall; say "Firewall aplicado. SSH protegido en ${SSH_PORT}/tcp.";
}
component_uninstall(){
  need_root; say '== Quitar configuración WISP de nftables =='
  local last; last=$(ls -1t "$GW_STATE"/backups/nftables.conf.* 2>/dev/null | head -1 || true)
  if [ -n "$last" ]; then cp -a "$last" /etc/nftables.conf; nft -c -f /etc/nftables.conf && systemctl restart nftables; say "Restaurado backup: $last"; else say 'No hay backup previo: por seguridad NO se vacía ni se desinstala nftables.'; fi
  unmark firewall
}
