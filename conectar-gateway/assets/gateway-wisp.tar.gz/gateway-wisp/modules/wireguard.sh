#!/bin/bash
component_install(){ need_root; need_debian; say '== WireGuard =='; ensure_network_conf; apt_install wireguard wireguard-tools; mark wireguard; say 'WireGuard instalado. La interfaz se crea desde WGDashboard o tu configuración existente.'; }
component_uninstall(){ need_root; say 'Se quitará solo la integración WISP; no se purga WireGuard ni se borra /etc/wireguard.'; unmark wireguard; }
