#!/bin/bash
component_install(){
  need_root; need_debian; say '== DNS filtrado =='; ensure_network_conf; apt_install curl
  local provider; provider=$(get_conf DNS_PROVIDER)
  say '1) ControlD  2) AdGuard Home  3) Technitium'
  local d; case "$provider" in controld) d=1;; adguard) d=2;; technitium) d=3;; *) d=2;; esac
  local choice; choice=$(ask 'Proveedor DNS' "$d")
  local WG_SERVER_IP WG_SUBNET; source "$GW_CONF"
  case "$choice" in
    1)
      provider=controld; set_conf DNS_PROVIDER controld
      local rid boot; rid=$(get_conf CONTROLD_RESOLVER_ID); [ -n "$rid" ] || rid=$(ask 'Resolver ID de ControlD' ''); [ -n "$rid" ] || { say 'Resolver ID obligatorio.'; exit 1; }; set_conf CONTROLD_RESOLVER_ID "$rid"
      boot=$(get_conf CONTROLD_BOOTSTRAP_IP); [ -n "$boot" ] || boot=$(ask 'Bootstrap IP' '76.76.2.22'); set_conf CONTROLD_BOOTSTRAP_IP "$boot"
      sh -c 'sh -c "$(curl -fsSL https://api.controld.com/dl)"'
      mkdir -p /etc/controld; cat > /etc/controld/ctrld.toml <<CFG
[service]
  cache_enable = true
  cache_size = 65536
[listener]
  [listener.0]
    ip = '${WG_SERVER_IP}'
    port = 53
[network]
  [network.0]
    cidrs = ["${WG_SUBNET}"]
    name = "Tunel WireGuard"
[upstream]
  [upstream.0]
    bootstrap_ip = "${boot}"
    endpoint = "https://dns.controld.com/${rid}"
    name = "ControlD"
    timeout = 5000
    type = "doh3"
CFG
      ;;
    3)
      provider=technitium; set_conf DNS_PROVIDER technitium
      local tp; tp=$(get_conf TECHNITIUM_PORT); valid_port "${tp:-}" || tp=$(ask 'Puerto panel Technitium' '5380'); valid_port "$tp" || exit 1; set_conf TECHNITIUM_PORT "$tp"
      read -r -p 'Technitium instala .NET y consume más RAM. ¿Continuar? [s/N]: ' ok; [[ "$ok" =~ ^[sS] ]] || exit 0
      curl -fsSL https://download.technitium.com/dns/install.sh | bash
      mkdir -p /etc/systemd/system/dns.service.d; cat > /etc/systemd/system/dns.service.d/gateway-wisp.conf <<CFG
[Service]
Environment=DNS_SERVER_LOCAL_ADDRESSES=${WG_SERVER_IP}
Environment=DNS_SERVER_WEB_SERVICE_LOCAL_ADDRESSES=127.0.0.1
Environment=DNS_SERVER_WEB_SERVICE_HTTP_PORT=${tp}
Environment=DNS_SERVER_WEB_SERVICE_ENABLE_HTTPS=false
Environment=DNS_SERVER_FORWARDERS=https://cloudflare-dns.com/dns-query,https://dns.quad9.net/dns-query
Environment=DNS_SERVER_FORWARDER_PROTOCOL=Https
Environment=DNS_SERVER_RECURSION=UseSpecifiedNetworks
Environment=DNS_SERVER_RECURSION_ALLOWED_NETWORKS=${WG_SUBNET},127.0.0.1
CFG
      systemctl daemon-reload
      ;;
    *)
      provider=adguard; set_conf DNS_PROVIDER adguard
      local ap; ap=$(get_conf ADGUARD_PORT); valid_port "${ap:-}" || ap=$(ask 'Puerto panel AdGuard Home' '3000'); valid_port "$ap" || exit 1; set_conf ADGUARD_PORT "$ap"
      curl -fsSL https://raw.githubusercontent.com/AdguardTeam/AdGuardHome/master/scripts/install.sh | sh -s -- -v
      say 'AdGuard Home instalado. Completa su asistente web por localhost y asegúrate de escuchar DNS en la IP de WireGuard.'
      ;;
  esac
  mark dns; say "DNS instalado/configurado: $provider";
}
component_uninstall(){ need_root; say 'Por seguridad se deshabilita la integración WISP pero no se purga el servidor DNS ni sus datos.'; unmark dns; }
