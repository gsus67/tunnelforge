#!/bin/bash
component_install(){
  need_root; need_debian; apt_install python3 gettext-base
  local p; p=$(get_conf PANEL_PORT); valid_port "${p:-}" || p=$(ask 'Puerto del panel local' '8888'); valid_port "$p" || exit 1; set_conf PANEL_PORT "$p"
  local PANEL_PORT="$p" PANEL_DIR; PANEL_DIR=$(get_conf PANEL_DIR); [ -n "$PANEL_DIR" ] || PANEL_DIR=/opt/panel-wisp; set_conf PANEL_DIR "$PANEL_DIR"; export PANEL_PORT PANEL_DIR
  mkdir -p "$PANEL_DIR"; install -m 0644 "$GW_ROOT/panel/index.html" "$PANEL_DIR/index.html"; install -m 0755 "$GW_ROOT/archivos/panel-api.py" /usr/local/sbin/panel-api.py
  envsubst '${PANEL_PORT} ${PANEL_DIR}' < "$GW_ROOT/systemd/panel-wisp.service.tpl" > /etc/systemd/system/panel-wisp.service
  systemctl daemon-reload; systemctl enable --now panel-wisp.service; mark panel; say "Panel activo en localhost:$PANEL_PORT.";
}
component_uninstall(){ need_root; systemctl disable --now panel-wisp.service 2>/dev/null || true; rm -f /etc/systemd/system/panel-wisp.service /usr/local/sbin/panel-api.py; systemctl daemon-reload; unmark panel; say 'Servicio del panel retirado. Los archivos del panel se conservan.'; }
