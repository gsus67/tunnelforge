#!/bin/bash
component_install(){ need_root; need_debian; apt_install curl; curl -fsSL https://get.netdata.cloud/kickstart.sh -o /tmp/netdata-kickstart.sh; sh /tmp/netdata-kickstart.sh --non-interactive; mark netdata; say 'Netdata instalado.'; }
component_uninstall(){ need_root; if marked netdata; then systemctl disable --now netdata 2>/dev/null || true; say 'Netdata detenido; no se purga automáticamente.'; fi; unmark netdata; }
