[service]
  cache_enable = true
  cache_size = 65536

[listener]

  [listener.0]
    ip = '${WG_SERVER_IP}'
    port = 53

[network]

  [network.0]
    cidrs = ["${WG_SUBNET}"]
    name = "Tunel WireGuard"

[upstream]

  [upstream.0]
    bootstrap_ip = "${CONTROLD_BOOTSTRAP_IP}"
    endpoint = "https://dns.controld.com/${CONTROLD_RESOLVER_ID}"
    name = "ControlD - redforce"
    timeout = 5000
    type = "doh3"
