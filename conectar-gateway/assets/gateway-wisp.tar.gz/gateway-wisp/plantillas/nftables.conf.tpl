#!/usr/sbin/nft -f

flush ruleset

table inet filter {
    chain input {
        type filter hook input priority 0; policy drop;

        # Conexiones ya establecidas
        ct state established,related accept

        # Loopback
        iif lo accept

        # Descarta paquetes invalidos
        ct state invalid drop

        # ICMP (ping)
        ip protocol icmp accept
        ip6 nexthdr icmpv6 accept

        # SSH — puerto actual detectado/gestionado por Gateway WISP Access
        tcp dport ${SSH_PORT} accept

        # Reglas extra persistentes administradas por Gateway WISP Access.
        # Los archivos contienen reglas de esta cadena (no tables completas).
        include "/etc/wisp/firewall.d/*.nft"

        # WireGuard
        udp dport ${WG_PORT} accept

        # DNS (ctrld) — solo desde el tunel
        iifname "${WG_IFACE}" udp dport 53 accept
        iifname "${WG_IFACE}" tcp dport 53 accept
    }

    chain forward {
        type filter hook forward priority 0; policy drop;

        ct state established,related accept
        ct state invalid drop

        # ===== MSS CLAMPING =====
        # El tunel tiene MTU 1420; sin esto, sitios que mandan paquetes
        # grandes se cuelgan o cargan a medias para los clientes.
        oifname "${WG_IFACE}" tcp flags syn tcp option maxseg size set rt mtu
        iifname "${WG_IFACE}" tcp flags syn tcp option maxseg size set rt mtu

        # ===== ANTI-SPOOFING =====
        # Solo se forwardea trafico del tunel cuyo origen sea del rango WG.
        # Un peer no puede inyectar paquetes con IP falsa.
        iifname "${WG_IFACE}" ip saddr != ${WG_SUBNET} drop

        # ===== AISLAMIENTO ENTRE CLIENTES =====
        # Los clientes del WISP no se ven entre si (peer -> peer bloqueado).
        iifname "${WG_IFACE}" oifname "${WG_IFACE}" drop

        # ===== PROTECCION DE REPUTACION - bloqueo de salida =====
        # SMTP saliente (spam) - causa #1 de blacklist
        iifname "${WG_IFACE}" tcp dport 25 drop
        iifname "${WG_IFACE}" tcp dport 465 drop
        iifname "${WG_IFACE}" tcp dport 587 drop
        iifname "${WG_IFACE}" tcp dport 2525 drop
        # Telnet saliente - gusanos IoT
        iifname "${WG_IFACE}" tcp dport 23 drop
        # SMB / NetBIOS - propagacion de malware
        iifname "${WG_IFACE}" tcp dport 135-139 drop
        iifname "${WG_IFACE}" tcp dport 445 drop
        iifname "${WG_IFACE}" udp dport 135-139 drop
        iifname "${WG_IFACE}" udp dport 445 drop
        # Bases de datos saliente
        iifname "${WG_IFACE}" tcp dport 1433 drop
        iifname "${WG_IFACE}" tcp dport 3306 drop
        # RDP saliente
        iifname "${WG_IFACE}" tcp dport 3389 drop
        # ===== FIN PROTECCION DE REPUTACION =====

        # Permitir que el tunel salga a internet
        iifname "${WG_IFACE}" oifname "${PUB_IFACE}" accept

        # Trafico de vuelta hacia el tunel
        iifname "${PUB_IFACE}" oifname "${WG_IFACE}" ct state established,related accept
    }

    chain output {
        type filter hook output priority 0; policy accept;
    }
}

table inet nat {
    # Redireccion DNS forzada — si un cliente pone 8.8.8.8, lo mandamos al resolver local (ctrld)
    chain prerouting {
        type nat hook prerouting priority -100;
        iifname "${WG_IFACE}" udp dport 53 redirect to :53
        iifname "${WG_IFACE}" tcp dport 53 redirect to :53
    }

    chain postrouting {
        type nat hook postrouting priority 100;
        ip saddr ${WG_SUBNET} oifname "${PUB_IFACE}" masquerade
    }
}

# =====================================================================
# QoS - MARCADO DSCP (CAKE en wg0 encola segun estas marcas)
# Prioridad: CS7 ping > CS6 juegos > CS4 social > CS2 streaming > CS0 resto
# EDITA LOS SETS segun los juegos/servicios de tus clientes.
# =====================================================================
table inet mangle {

    # Puertos UDP tipicos de juegos (Xbox/PSN, CoD, GTA, Steam, Fortnite...)
    set juegos_udp {
        type inet_service
        flags interval
        elements = { 3074, 3478-3480, 3658, 6672, 9295-9309, 27000-27100 }
    }

    # Puertos TCP de juegos
    set juegos_tcp {
        type inet_service
        flags interval
        elements = { 3074, 27015-27050 }
    }

    # Rangos IP de social media (Meta/FB/IG/WhatsApp + X/Twitter)
    # Actualizar con: whois -h whois.radb.net '!gAS32934' (Meta) / AS13414 (X)
    set redes_social {
        type ipv4_addr
        flags interval
        auto-merge
        elements = { 31.13.24.0/21, 31.13.64.0/18, 66.220.144.0/20,
                     69.63.176.0/20, 157.240.0.0/16, 179.60.192.0/22,
                     185.60.216.0/22, 104.244.40.0/21, 199.16.156.0/22 }
    }

    # Rangos IP de streaming (Netflix/OCA). YouTube/Twitch comparten CDN
    # con todo Google/Amazon: no se pueden separar por IP y caen en "resto".
    set redes_streaming {
        type ipv4_addr
        flags interval
        auto-merge
        elements = { 23.246.0.0/18, 37.77.184.0/21, 45.57.0.0/17,
                     108.175.32.0/20, 198.38.96.0/19, 198.45.48.0/20 }
    }

    chain forward {
        type filter hook forward priority mangle; policy accept;

        # 1) PING / ICMP — maxima prioridad
        ip protocol icmp ip dscp set cs7 return

        # 2) JUEGOS — por puerto, ambas direcciones
        udp sport @juegos_udp ip dscp set cs6 return
        udp dport @juegos_udp ip dscp set cs6 return
        tcp sport @juegos_tcp ip dscp set cs6 return
        tcp dport @juegos_tcp ip dscp set cs6 return

        # 3) SOCIAL — por rango IP, ambas direcciones
        ip saddr @redes_social ip dscp set cs4 return
        ip daddr @redes_social ip dscp set cs4 return

        # 4) STREAMING — por rango IP, ambas direcciones
        ip saddr @redes_streaming ip dscp set cs2 return
        ip daddr @redes_streaming ip dscp set cs2 return

        # 5) RESTO — queda en CS0 (best effort), no hace falta regla
    }
}

