#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$ROOT/lib/common.sh"
need_root
say 'Gateway WISP - desinstalación segura'
say 'Se retirarán configuraciones y servicios administrados por Gateway WISP.'
say 'NO se purgarán automáticamente WireGuard, nftables, CrowdSec, DNS, Netdata ni sus datos.'
ask_yes_no '¿Continuar?' 'N' || exit 0
mkdir -p "$GW_BACKUP"
backup="$GW_BACKUP/uninstall-$(date +%Y%m%d_%H%M%S).tar.gz"
tar -czf "$backup" --ignore-failed-read /etc/wisp /etc/nftables.conf /etc/systemd/system/qos-cake-wg0.service /etc/systemd/system/panel-wisp.service /etc/systemd/system/udp-gro-forwarding.service 2>/dev/null || true
say "Backup previo: $backup"
for c in panel maintenance netdata crowdsec wgdashboard dns qos firewall wireguard system; do
  if [ -f "$ROOT/modules/$c.sh" ]; then
    # shellcheck disable=SC1090
    source "$ROOT/modules/$c.sh"; component_uninstall || true; unset -f component_install component_uninstall 2>/dev/null || true
  fi
done
if [ -d /etc/wisp ]; then mv /etc/wisp "/etc/wisp.removed.$(date +%Y%m%d_%H%M%S)"; fi
rm -rf "$GW_MARKERS" 2>/dev/null || true
say 'Desinstalación segura terminada. Paquetes de terceros y datos principales se conservaron.'
