#!/bin/bash
# ==============================================================================
# chequear-updates.sh — corre cada 6h (timer systemd)
# ==============================================================================
# Segun AUTO_UPDATE_MODO en /etc/wisp/config.env:
#   aviso (default): git fetch; si hay cambios en origin/main, prende el badge
#                    del panel. TU decides cuando correr actualizar.sh.
#   tags:            aplica automaticamente el ULTIMO TAG publicado (v1.3,
#                    v1.4...). Los commits sueltos de main NUNCA se aplican
#                    solos: publicar un tag es tu boton de "esto va".
# ==============================================================================

set -u

REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_DIR"

MODO="aviso"
PANEL_DIR="/opt/panel-wisp"
[ -f /etc/wisp/config.env ] && source /etc/wisp/config.env
MODO="${AUTO_UPDATE_MODO:-$MODO}"
PANEL_DIR="${PANEL_DIR:-/opt/panel-wisp}"

# Traer lo nuevo (rama + tags). Si no hay red/GitHub, salir sin drama.
if ! git fetch --tags origin 2>/dev/null; then
    echo "chequear-updates: sin acceso al repo remoto (¿red? ¿deploy key?). Reintento en 6h."
    exit 0
fi

ACTUAL=$(git rev-parse HEAD)

escribir_aviso() {   # $1 = disponible  $2 = version  $3 = archivo con cambios (o "-")
    python3 - "$1" "$2" "${3:--}" > "$PANEL_DIR/update.json" 2>/dev/null << 'PY' || true
import json, sys, datetime
disp = sys.argv[1] == "true"
cambios = []
if sys.argv[3] != "-":
    try:
        cambios = [l.strip() for l in open(sys.argv[3]) if l.strip()][:15]
    except OSError:
        pass
print(json.dumps({"disponible": disp, "version": sys.argv[2],
                  "cambios": cambios,
                  "chequeado": datetime.datetime.now().isoformat(timespec="seconds")}))
PY
}

case "$MODO" in

  tags)
    ULTIMO_TAG=$(git tag --sort=-v:refname | head -1)
    if [ -z "$ULTIMO_TAG" ]; then
        echo "chequear-updates(tags): no hay tags publicados todavia."
        escribir_aviso false ""
        exit 0
    fi
    TAG_COMMIT=$(git rev-parse "${ULTIMO_TAG}^{commit}")
    if [ "$ACTUAL" = "$TAG_COMMIT" ]; then
        echo "chequear-updates(tags): ya en ${ULTIMO_TAG}."
        escribir_aviso false "$ULTIMO_TAG"
        exit 0
    fi
    CAMBIOS_TMP=$(mktemp)
    git log --format="%s" "HEAD..${ULTIMO_TAG}" 2>/dev/null > "$CAMBIOS_TMP" || true
    echo "chequear-updates(tags): aplicando ${ULTIMO_TAG}..."
    git checkout -q "$ULTIMO_TAG"
    if bash "$REPO_DIR/actualizar.sh"; then
        echo "chequear-updates(tags): ${ULTIMO_TAG} aplicado OK."
        rm -f "$CAMBIOS_TMP"
    else
        echo "chequear-updates(tags): ERROR aplicando ${ULTIMO_TAG}. Revisa a mano."
        escribir_aviso true "${ULTIMO_TAG} (FALLO al aplicar)" "$CAMBIOS_TMP"
    fi
    ;;

  aviso|*)
    REMOTO=$(git rev-parse origin/main 2>/dev/null || git rev-parse origin/master 2>/dev/null || echo "$ACTUAL")
    if [ "$ACTUAL" != "$REMOTO" ]; then
        N=$(git rev-list --count HEAD..origin/main 2>/dev/null || echo "?")
        VERSION=$(git describe --tags --always origin/main 2>/dev/null || echo "nueva")
        CAMBIOS_TMP=$(mktemp)
        git log --format="%s" HEAD..origin/main 2>/dev/null > "$CAMBIOS_TMP" || true
        echo "chequear-updates(aviso): hay ${N} commit(s) nuevos (${VERSION})."
        escribir_aviso true "$VERSION" "$CAMBIOS_TMP"
        rm -f "$CAMBIOS_TMP"
    else
        echo "chequear-updates(aviso): al dia."
        escribir_aviso false "$(git describe --tags --always 2>/dev/null || echo '')"
    fi
    ;;
esac
