[Unit]
Description=Panel de control del gateway WISP (localhost:${PANEL_PORT})
After=network.target

[Service]
Type=simple
Environment=WG_IFACE=${WG_IFACE}
Environment=PANEL_DIR=${PANEL_DIR}
Environment=PANEL_PORT=${PANEL_PORT}
Environment=REPO_DIR=/opt/gateway-wisp
ExecStart=/usr/bin/python3 /usr/local/sbin/panel-api.py
Restart=on-failure
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=full
ProtectHome=read-only
ReadWritePaths=/opt/gateway-wisp ${PANEL_DIR}

[Install]
WantedBy=multi-user.target
