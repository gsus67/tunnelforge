[Unit]
Description=QoS CAKE diffserv8 en ${WG_IFACE}
After=wg-quick@${WG_IFACE}.service network-online.target

[Service]
Type=oneshot
ExecStart=/usr/sbin/tc qdisc replace dev ${WG_IFACE} root cake ${CAKE_OPTS}
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
