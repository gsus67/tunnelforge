# Gateway WISP — WireGuard

Aprovisionamiento completo de un VPS Debian como **gateway de salida para un
WISP**: los clientes entran por un túnel WireGuard y salen a internet por la IP
del VPS, con filtrado DNS, QoS por tipo de tráfico, protección de la reputación
de la IP y monitoreo.

Un solo script convierte un Debian recién instalado en un gateway operativo.
La configuración vive versionada en este repo, así que los servidores se
mantienen actualizados desde aquí.

---

## Qué resuelve

- **Protege la reputación de la IP**: bloquea de salida los puertos que causan
  listas negras (SMTP, telnet, SMB, RDP, bases de datos), de modo que un cliente
  infectado no arrastra a todos los demás.
- **Aísla a los clientes entre sí**: un peer no ve a otro peer.
- **Prioriza lo que importa**: ping y juegos por delante de redes sociales,
  streaming y descargas, con reparto justo de ancho de banda entre clientes.
- **Filtra DNS**: publicidad, malware y rastreadores, con el tráfico DNS cifrado.
- **Se defiende solo**: baneo automático de atacantes y parches de seguridad
  automáticos.
- **Se ve**: panel propio con tráfico en vivo por cliente y monitoreo en tiempo real.

---

## Qué instala

| Componente | Función |
|---|---|
| **WireGuard** + WGDashboard | Túnel y gestión de clientes por web |
| **nftables** | Firewall, NAT, anti-spoofing, aislamiento, bloqueo de salida, DNS forzado |
| **CAKE** (tc) | QoS por DSCP: ping › juegos › social › streaming › resto |
| **ControlD**, **AdGuard Home** o **Technitium** | Filtrado DNS (se elige al instalar) |
| **CrowdSec** + bouncer nftables | Detección y baneo de atacantes, con métricas Prometheus |
| **Netdata** | Monitoreo en tiempo real |
| **vnstat** | Contabilidad de tráfico mensual |
| **Panel de control** | Vista propia con tráfico por peer y accesos a todo |
| Timers systemd | Backups diarios, actualización de IPs de QoS, chequeo de updates |

Dimensionado para ~1000 clientes y ~1 Gbps: conntrack de 1M entradas, buffers
UDP ampliados, `fq_codel`, GRO forwarding e `irqbalance`.

**Ningún panel se expone a internet**: todos escuchan en `127.0.0.1` y se
acceden por túnel SSH.

---

## Requisitos

- VPS con **Debian 12 o superior**, acceso root e IP pública
- Un MikroTik (u otro router) como cliente WireGuard del lado del WISP
- Si eliges ControlD: una cuenta y tu *Resolver ID*

---

## Instalación

```bash
git clone https://github.com/gsus67/gateway-wisp-wireguard.git /opt/gateway-wisp
sudo bash /opt/gateway-wisp/setup-vps-wisp.sh
```

El instalador **pregunta la configuración por pantalla**, con sugerencias entre
corchetes que se aceptan con Enter:

- Puerto WireGuard y subred del túnel — **se sugieren al azar** para que cada
  gateway sea distinto (menos escaneos, y sin choques con las LAN de tus clientes)
- Filtrado DNS: **ControlD**, **AdGuard Home** o **Technitium** (ver tabla abajo)
- Límite del shaper CAKE, puerto del panel y modo de actualización

Todo queda en `/etc/wisp/config.env` (permisos 600, fuera del repo: ahí viven
tus datos sensibles). Si el archivo ya existe, el instalador pregunta si
reutilizarlo.

### Opciones de DNS

| | Dónde vive | RAM aprox. | Cuándo elegirlo |
|---|---|---|---|
| **ControlD** | Nube (ctrld local hace DoH3) | ~15 MB | Cero mantenimiento; reglas y estadísticas en su panel web |
| **AdGuard Home** | Este VPS | ~20-50 MB | **Recomendado** para filtrar: tus reglas, tus logs, panel propio |
| **Technitium** | Este VPS | ~80-150 MB | Solo si además necesitas **zonas propias / DNS interno**; corre sobre .NET y pesa 3-4× más |

Los tres cifran el tráfico DNS saliente. Los dos autohospedados exponen su panel
**solo en localhost** (acceso por túnel SSH) y se administran desde ahí:
`actualizar.sh` nunca sobrescribe sus reglas.

### Después de instalar

El script imprime los pasos finales en orden. En resumen:

1. **Crear la interfaz** `wg0` desde WGDashboard (puerto 10086 vía túnel SSH),
   con máscara `/24` — no `/32`
2. `systemctl enable wg-quick@wg0` y `systemctl start qos-cake-wg0`
3. Arrancar el DNS elegido (`ctrld start ...` o `systemctl start AdGuardHome`)
4. Verificar el filtrado: `dig doubleclick.net @10.x.x.1 +short` debe dar `0.0.0.0`
5. Crear los peers desde WGDashboard
6. Cambiar el puerto SSH al final

---

## Acceso a los paneles

Todo vive en localhost del VPS. Abre el túnel desde tu PC:

```bash
ssh -N -L 8888:127.0.0.1:8888 -L 10086:127.0.0.1:10086 \
       -L 19999:127.0.0.1:19999 -L 6060:127.0.0.1:6060 \
       -L 60601:127.0.0.1:60601 usuario@IP_DEL_VPS
```

| URL | Panel |
|---|---|
| `localhost:8888` | Panel del gateway — tráfico en vivo por peer, estado, accesos |
| `localhost:10086` | WGDashboard — crear y gestionar peers |
| `localhost:19999` | Netdata — CPU, red, conntrack, métricas de CrowdSec |
| `localhost:3000` | AdGuard Home *(si es el DNS elegido)* |
| `localhost:6060` · `:60601` | Métricas Prometheus de CrowdSec y su bouncer |

> La app [**Conectar Gateway**](https://github.com/gsus67/gateway-wisp-access)
> abre todos estos túneles de un clic y trae terminal SSH integrado.

---

## QoS — cómo funciona

nftables marca cada paquete con un DSCP según su tipo, y CAKE lo encola por
prioridad en `wg0`:

| Prioridad | Tráfico | DSCP |
|---|---|---|
| 1 | Ping / ICMP | CS7 |
| 2 | Juegos (por puerto) | CS6 |
| 3 | Redes sociales (por rango IP) | CS4 |
| 4 | Streaming (por rango IP) | CS2 |
| 5 | Todo lo demás | CS0 |

Los rangos IP de redes sociales y streaming **se actualizan solos cada semana**
consultando RADB por ASN (`/usr/local/sbin/actualizar-qos-ips.sh`). Los puertos
de juegos se editan en la plantilla `plantillas/nftables.conf.tpl`.

**El cuello de botella real de un WISP está en los radios, no en el VPS.** El
DSCP viaja dentro del túnel cifrado, así que el MikroTik lo lee al descifrar:
replicando ahí colas por DSCP se prioriza donde de verdad se congestiona.

---

## Mantener los servidores actualizados

Las mejoras se hacen **en este repo** (`plantillas/`, `panel/`, `archivos/`,
`systemd/`), nunca editando archivos a mano en el VPS: la próxima sincronización
los sobrescribe.

Cada servidor clona el repo y ejecuta:

```bash
cd /opt/gateway-wisp && git pull && sudo bash actualizar.sh
```

`actualizar.sh` es **idempotente**: compara archivo por archivo, aplica solo lo
que cambió y reinicia únicamente los servicios afectados. Correrlo dos veces
seguidas no hace nada la segunda vez.

**Seguridad al aplicar:** la configuración de nftables se valida con `nft -c`
*antes* de instalarse; si la plantilla tuviera un error, el firewall queda
intacto y el script aborta.

### Chequeo automático

```bash
sudo systemctl enable --now chequear-updates.timer   # cada 6 h
```

Según `AUTO_UPDATE_MODO` en `config.env`:

- **`aviso`** (recomendado): detecta cambios y los anuncia en el panel con la
  lista de novedades. Tú decides cuándo aplicarlos.
- **`tags`**: aplica automáticamente las versiones publicadas como tag. Los
  commits sueltos nunca se aplican solos; publicar un tag es el botón de desplegar.

### Acceso al repo desde el VPS

Repo privado: cada servidor usa su propia **deploy key de solo lectura**
(GitHub → repo → Settings → Deploy keys, sin marcar *Allow write access*):

```bash
ssh-keygen -t ed25519 -f /root/.ssh/gateway-deploy -N "" -C "gateway"
cat /root/.ssh/gateway-deploy.pub    # pegar en GitHub
```

Una llave por servidor, revocables por separado.

---

## Estructura del repo

```
setup-vps-wisp.sh     Instalación inicial: Debian limpio → gateway operativo
actualizar.sh         Sincroniza las configuraciones del repo en el servidor
config.env.ejemplo    Plantilla de variables → /etc/wisp/config.env
plantillas/           nftables y ctrld, renderizadas con tus variables
panel/                Panel de control (HTML + API en Python)
archivos/             Scripts: IPs de QoS, backup, API del panel
systemd/              Servicios y timers
auto-update/          Chequeo periódico de versiones nuevas
```

---

## Operación diaria

```bash
cat /etc/wisp/version                  # versión desplegada en este servidor
cscli decisions list                   # IPs baneadas ahora mismo
vnstat -m                              # tráfico del mes
tc -s qdisc show dev wg0               # colas y prioridades de QoS
sudo /usr/local/sbin/backup-wisp.sh    # backup manual
journalctl -u chequear-updates -n 20   # historial de chequeos de versión
```

Los backups diarios (03:30) guardan configuración de WireGuard, nftables, DNS,
CrowdSec y la base de peers en `/var/backups/wisp`, con rotación de 14 días.
**Cópialos fuera del VPS**: con ese archivo y este repo, el gateway se
reconstruye completo en minutos.

---

## Versionado

`MAYOR.menor.parche` — ver [CHANGELOG.md](CHANGELOG.md) para el detalle de cada
versión.

- **parche**: correcciones
- **menor**: funcionalidad nueva compatible
- **MAYOR**: cambio estructural o que rompe compatibilidad

## Gestor modular 1.5.0

El paquete puede usarse completo o por componentes. Las operaciones automáticas
están limitadas a Debian/Ubuntu para evitar aplicar comandos `apt` en una
distribución incompatible.

```bash
sudo ./gateway-wisp-manager install full
./gateway-wisp-manager status
sudo ./gateway-wisp-manager component install firewall
sudo ./gateway-wisp-manager component install dns
sudo ./gateway-wisp-manager component uninstall qos
sudo ./gateway-wisp-manager uninstall full
```

La desinstalación es conservadora: crea una copia previa y no purga de forma
automática paquetes o datos de terceros. Los componentes preguntan por la
configuración necesaria en la terminal y guardan los valores WISP en
`/etc/wisp/config.env` con permisos restrictivos.
