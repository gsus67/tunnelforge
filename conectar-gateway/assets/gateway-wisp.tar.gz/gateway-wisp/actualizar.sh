#!/bin/bash
# ==============================================================================
# actualizar.sh — Re-aplica las configs del repo en este VPS (idempotente)
# ==============================================================================
# NO instala paquetes ni hace upgrades: eso es trabajo de setup-vps-wisp.sh
# (bootstrap inicial). Este script solo sincroniza:
#   - /etc/nftables.conf        (validado con nft -c ANTES de tocar nada)
#   - /etc/controld/ctrld.toml
#   - Panel de control (HTML)
#   - Scripts auxiliares (QoS IPs, backup)
#   - Unidades systemd (CAKE, GRO, panel, timers)
# y reinicia SOLO lo que cambio. Correr las veces que quieras: si nada
# cambio, no toca nada.
# ==============================================================================
# Uso: sudo bash actualizar.sh
# ==============================================================================

set -e

REPO_DIR="$(cd "$(dirname "$0")" && pwd)"
CONF="/etc/wisp/config.env"

if [ ! -f "$CONF" ]; then
    echo "ERROR: falta $CONF"
    echo "  sudo mkdir -p /etc/wisp"
    echo "  sudo cp ${REPO_DIR}/config.env.ejemplo $CONF"
    echo "  sudo nano $CONF   (pon tu resolver ID y ajusta)"
    exit 1
fi
source "$CONF"

# Interfaz publica: autodetectar si no viene en la config
if [ -z "${PUB_IFACE:-}" ]; then
    PUB_IFACE=$(ip -o -4 route show to default | awk '{print $5}' | head -1)
fi
[ -n "$PUB_IFACE" ] || { echo "ERROR: no se detecto interfaz publica."; exit 1; }

# Opciones del CAKE derivadas de la config
CAKE_OPTS="diffserv8 dual-dsthost"
if [ -n "${CAKE_BANDWIDTH:-}" ]; then
    CAKE_OPTS="bandwidth ${CAKE_BANDWIDTH} ${CAKE_OPTS}"
fi

SSH_PORT="${SSH_PORT:-$(sshd -T 2>/dev/null | awk '$1=="port"{print $2; exit}')}"
SSH_PORT="${SSH_PORT:-22}"
mkdir -p /etc/wisp/firewall.d
[ -f /etc/wisp/firewall.d/90-local-ports.nft ] || printf '# Reglas persistentes administradas por Gateway WISP Access\n' > /etc/wisp/firewall.d/90-local-ports.nft

PANEL_DIR="${PANEL_DIR:-/opt/panel-wisp}"
PANEL_PORT="${PANEL_PORT:-8888}"

DNS_PROVIDER="${DNS_PROVIDER:-controld}"
ADGUARD_PORT="${ADGUARD_PORT:-3000}"
TECHNITIUM_PORT="${TECHNITIUM_PORT:-5380}"

export WG_PORT WG_SUBNET WG_SERVER_IP WG_IFACE PUB_IFACE \
       CONTROLD_RESOLVER_ID CONTROLD_BOOTSTRAP_IP \
       CAKE_OPTS PANEL_PORT PANEL_DIR DNS_PROVIDER ADGUARD_PORT TECHNITIUM_PORT SSH_PORT

# Lista EXPLICITA de variables que envsubst puede tocar (nada mas se expande)
VARS='${WG_PORT} ${WG_SUBNET} ${WG_SERVER_IP} ${WG_IFACE} ${PUB_IFACE} ${CONTROLD_RESOLVER_ID} ${CONTROLD_BOOTSTRAP_IP} ${CAKE_OPTS} ${PANEL_PORT} ${PANEL_DIR} ${SSH_PORT}'

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
CAMBIOS=0
RECARGA_UNIDADES=0

# instalar <origen> <destino> <permisos>  -> devuelve 0 si hubo cambio
instalar() {
    if ! cmp -s "$1" "$2" 2>/dev/null; then
        install -D -m "$3" "$1" "$2"
        echo "  actualizado: $2"
        CAMBIOS=1
        return 0
    fi
    return 1
}

echo "=============================================="
echo " Sincronizando configs desde el repo "
echo " ($(git -C "$REPO_DIR" describe --tags --always 2>/dev/null || echo 'sin git'))"
echo "=============================================="

# ------------------------------------------------------------------------------
# 1) nftables — validar SIEMPRE antes de instalar
# ------------------------------------------------------------------------------
envsubst "$VARS" < "$REPO_DIR/plantillas/nftables.conf.tpl" > "$TMP/nftables.conf"
if ! cmp -s "$TMP/nftables.conf" /etc/nftables.conf; then
    if nft -c -f "$TMP/nftables.conf"; then
        cp /etc/nftables.conf "/etc/nftables.conf.bak.$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
        install -m 0644 "$TMP/nftables.conf" /etc/nftables.conf
        systemctl restart nftables
        # bouncer de CrowdSec y refresco de IPs QoS se reinician solos (PartOf)
        echo "  actualizado: /etc/nftables.conf (firewall recargado)"
        CAMBIOS=1
    else
        echo "  ERROR: la plantilla de nftables NO valida. Firewall intacto. Abortando."
        exit 1
    fi
fi

# ------------------------------------------------------------------------------
# 2) DNS — segun el proveedor elegido en la instalacion
# ------------------------------------------------------------------------------
if [ "${DNS_PROVIDER:-controld}" = "technitium" ]; then
    # Technitium se administra desde su propio panel: el repo NO pisa su
    # configuracion (zonas, listas y reglas viven ahi). Solo verificamos.
    if systemctl list-unit-files 2>/dev/null | grep -q "^dns.service"; then
        systemctl is-active --quiet dns \
            || echo "  AVISO: Technitium (dns) no esta corriendo (systemctl start dns)."
    fi
elif [ "${DNS_PROVIDER:-controld}" = "adguard" ]; then
    # AdGuard Home se administra desde su propio panel web: el repo NO pisa su
    # configuracion (tus reglas y listas viven ahi). Solo verificamos que corra.
    if systemctl list-unit-files 2>/dev/null | grep -q AdGuardHome; then
        systemctl is-active --quiet AdGuardHome \
            || echo "  AVISO: AdGuardHome no esta corriendo (systemctl start AdGuardHome)."
    fi
else
    envsubst "$VARS" < "$REPO_DIR/plantillas/ctrld.toml.tpl" > "$TMP/ctrld.toml"
    if instalar "$TMP/ctrld.toml" /etc/controld/ctrld.toml 0644; then
        systemctl restart ctrld 2>/dev/null \
            || ctrld restart 2>/dev/null \
            || echo "  AVISO: reinicia ctrld a mano para aplicar el DNS."
    fi
fi

# ------------------------------------------------------------------------------
# 3) Panel de control
# ------------------------------------------------------------------------------
instalar "$REPO_DIR/panel/index.html" "$PANEL_DIR/index.html" 0644 || true

# ------------------------------------------------------------------------------
# 4) Scripts auxiliares
# ------------------------------------------------------------------------------
instalar "$REPO_DIR/archivos/actualizar-qos-ips.sh" /usr/local/sbin/actualizar-qos-ips.sh 0755 || true
instalar "$REPO_DIR/archivos/backup-wisp.sh"        /usr/local/sbin/backup-wisp.sh        0755 || true
if instalar "$REPO_DIR/archivos/panel-api.py"       /usr/local/sbin/panel-api.py          0755; then
    systemctl is-active --quiet panel-wisp && systemctl restart panel-wisp \
        && echo "  reiniciado: panel-wisp (API nueva)" || true
fi

# ------------------------------------------------------------------------------
# 5) Unidades systemd (plantillas renderizadas + estaticas)
# ------------------------------------------------------------------------------
for tpl in qos-cake-wg0.service udp-gro-forwarding.service panel-wisp.service; do
    envsubst "$VARS" < "$REPO_DIR/systemd/${tpl}.tpl" > "$TMP/$tpl"
    if instalar "$TMP/$tpl" "/etc/systemd/system/$tpl" 0644; then
        RECARGA_UNIDADES=1
        REINICIAR="$REINICIAR $tpl"
    fi
done
for u in actualizar-qos-ips.service actualizar-qos-ips.timer \
         backup-wisp.service backup-wisp.timer \
         chequear-updates.service chequear-updates.timer; do
    if instalar "$REPO_DIR/systemd/$u" "/etc/systemd/system/$u" 0644; then
        RECARGA_UNIDADES=1
    fi
done

if [ "$RECARGA_UNIDADES" -eq 1 ]; then
    systemctl daemon-reload
    for s in ${REINICIAR:-}; do
        systemctl is-active --quiet "$s" && systemctl restart "$s" \
            && echo "  reiniciado: $s" || true
    done
fi

# El panel necesita saber que DNS usamos, para mostrar el enlace correcto
PUERTO_DNS="$ADGUARD_PORT"
[ "$DNS_PROVIDER" = "technitium" ] && PUERTO_DNS="$TECHNITIUM_PORT"
printf '{"proveedor":"%s","puerto":%s}\n' "$DNS_PROVIDER" "$PUERTO_DNS" \
    > "$PANEL_DIR/dns.json" 2>/dev/null || true

# ------------------------------------------------------------------------------
# 6) Registrar version desplegada + limpiar aviso del panel
# ------------------------------------------------------------------------------
mkdir -p /etc/wisp
git -C "$REPO_DIR" describe --tags --always 2>/dev/null > /etc/wisp/version || true
echo '{"disponible": false}' > "$PANEL_DIR/update.json" 2>/dev/null || true

echo ""
if [ "$CAMBIOS" -eq 1 ]; then
    echo "Sincronizacion completada CON cambios aplicados."
else
    echo "Todo ya estaba al dia. No se toco nada."
fi
echo "Version desplegada: $(cat /etc/wisp/version 2>/dev/null || echo '?')"
